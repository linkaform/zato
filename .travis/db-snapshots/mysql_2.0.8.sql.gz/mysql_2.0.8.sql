-- MySQL dump 10.15  Distrib 10.0.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: my208
-- ------------------------------------------------------
-- Server version	10.0.31-MariaDB-0ubuntu0.16.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('0028_ae3419a9');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aws_s3`
--

DROP TABLE IF EXISTS `aws_s3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aws_s3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `pool_size` int(11) NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `debug_level` int(11) NOT NULL,
  `suppr_cons_slashes` tinyint(1) NOT NULL,
  `content_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `metadata_` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bucket` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encrypt_at_rest` tinyint(1) NOT NULL,
  `storage_class` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `security_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `security_id` (`security_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `aws_s3_ibfk_1` FOREIGN KEY (`security_id`) REFERENCES `sec_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `aws_s3_ibfk_2` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aws_s3`
--

LOCK TABLES `aws_s3` WRITE;
/*!40000 ALTER TABLE `aws_s3` DISABLE KEYS */;
/*!40000 ALTER TABLE `aws_s3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_amqp`
--

DROP TABLE IF EXISTS `channel_amqp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_amqp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `queue` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `consumer_tag_prefix` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `data_format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`def_id`),
  KEY `service_id` (`service_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `channel_amqp_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_amqp_ibfk_2` FOREIGN KEY (`def_id`) REFERENCES `conn_def_amqp` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_amqp`
--

LOCK TABLES `channel_amqp` WRITE;
/*!40000 ALTER TABLE `channel_amqp` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_amqp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_wmq`
--

DROP TABLE IF EXISTS `channel_wmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_wmq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `queue` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `data_format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`def_id`),
  KEY `service_id` (`service_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `channel_wmq_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_wmq_ibfk_2` FOREIGN KEY (`def_id`) REFERENCES `conn_def_wmq` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_wmq`
--

LOCK TABLES `channel_wmq` WRITE;
/*!40000 ALTER TABLE `channel_wmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_wmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_zmq`
--

DROP TABLE IF EXISTS `channel_zmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_zmq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `socket_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sub_key` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `service_id` (`service_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `channel_zmq_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_zmq_ibfk_2` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_zmq`
--

LOCK TABLES `channel_zmq` WRITE;
/*!40000 ALTER TABLE `channel_zmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_zmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cluster`
--

DROP TABLE IF EXISTS `cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cluster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `odb_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `odb_host` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `odb_port` int(11) DEFAULT NULL,
  `odb_user` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `odb_db_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `odb_schema` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `broker_host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `broker_port` int(11) NOT NULL,
  `lb_host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `lb_port` int(11) NOT NULL,
  `lb_agent_port` int(11) NOT NULL,
  `cw_srv_id` int(11) DEFAULT NULL,
  `cw_srv_keep_alive_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cluster`
--

LOCK TABLES `cluster` WRITE;
/*!40000 ALTER TABLE `cluster` DISABLE KEYS */;
INSERT INTO `cluster` VALUES (1,'quickstart-966733','Created by dmw@zato on 2018-01-25T02:59:13.415365 (UTC)','mysql+pymysql','localhost',3306,'dmw','my208',NULL,'localhost',6379,'localhost',11223,20151,NULL,NULL);
/*!40000 ALTER TABLE `cluster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conn_def_amqp`
--

DROP TABLE IF EXISTS `conn_def_amqp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conn_def_amqp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `def_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `vhost` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `frame_max` int(11) NOT NULL,
  `heartbeat` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`,`def_type`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `conn_def_amqp_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conn_def_amqp`
--

LOCK TABLES `conn_def_amqp` WRITE;
/*!40000 ALTER TABLE `conn_def_amqp` DISABLE KEYS */;
/*!40000 ALTER TABLE `conn_def_amqp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conn_def_cassandra`
--

DROP TABLE IF EXISTS `conn_def_cassandra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conn_def_cassandra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `contact_points` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `exec_size` int(11) NOT NULL,
  `proto_version` int(11) NOT NULL,
  `cql_version` int(11) DEFAULT NULL,
  `default_keyspace` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tls_ca_certs` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tls_client_cert` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tls_client_priv_key` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `conn_def_cassandra_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conn_def_cassandra`
--

LOCK TABLES `conn_def_cassandra` WRITE;
/*!40000 ALTER TABLE `conn_def_cassandra` DISABLE KEYS */;
/*!40000 ALTER TABLE `conn_def_cassandra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conn_def_wmq`
--

DROP TABLE IF EXISTS `conn_def_wmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conn_def_wmq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `queue_manager` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `channel` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cache_open_send_queues` tinyint(1) NOT NULL,
  `cache_open_receive_queues` tinyint(1) NOT NULL,
  `use_shared_connections` tinyint(1) NOT NULL,
  `dynamic_queue_template` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'SYSTEM.DEFAULT.MODEL.QUEUE',
  `ssl` tinyint(1) NOT NULL,
  `ssl_cipher_spec` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ssl_key_repository` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `needs_mcd` tinyint(1) NOT NULL,
  `max_chars_printed` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `conn_def_wmq_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conn_def_wmq`
--

LOCK TABLES `conn_def_wmq` WRITE;
/*!40000 ALTER TABLE `conn_def_wmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `conn_def_wmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `creation_time` datetime NOT NULL,
  `args` mediumblob,
  `kwargs` mediumblob,
  `last_used` datetime DEFAULT NULL,
  `resubmit_count` int(11) NOT NULL,
  `state` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `source_count` int(11) NOT NULL,
  `target_count` int(11) NOT NULL,
  `definition_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_delivery_task_id` (`task_id`),
  KEY `definition_id` (`definition_id`),
  KEY `ix_delivery_state` (`state`),
  CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `delivery_def_base` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_def_base`
--

DROP TABLE IF EXISTS `delivery_def_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_def_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `short_def` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `last_used` datetime DEFAULT NULL,
  `target_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `callback_list` blob,
  `expire_after` int(11) NOT NULL,
  `expire_arch_succ_after` int(11) NOT NULL,
  `expire_arch_fail_after` int(11) NOT NULL,
  `check_after` int(11) NOT NULL,
  `retry_repeats` int(11) NOT NULL,
  `retry_seconds` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `ix_delivery_def_base_name` (`name`),
  CONSTRAINT `delivery_def_base_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_def_base`
--

LOCK TABLES `delivery_def_base` WRITE;
/*!40000 ALTER TABLE `delivery_def_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_def_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_def_out_wmq`
--

DROP TABLE IF EXISTS `delivery_def_out_wmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_def_out_wmq` (
  `id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `target_id` (`target_id`),
  CONSTRAINT `delivery_def_out_wmq_ibfk_1` FOREIGN KEY (`id`) REFERENCES `delivery_def_base` (`id`),
  CONSTRAINT `delivery_def_out_wmq_ibfk_2` FOREIGN KEY (`target_id`) REFERENCES `out_wmq` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_def_out_wmq`
--

LOCK TABLES `delivery_def_out_wmq` WRITE;
/*!40000 ALTER TABLE `delivery_def_out_wmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_def_out_wmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_history`
--

DROP TABLE IF EXISTS `delivery_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `entry_type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `entry_time` datetime NOT NULL,
  `entry_ctx` mediumblob NOT NULL,
  `resubmit_count` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_delivery_history_task_id` (`task_id`),
  KEY `delivery_id` (`delivery_id`),
  KEY `ix_delivery_history_entry_time` (`entry_time`),
  CONSTRAINT `delivery_history_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_history`
--

LOCK TABLES `delivery_history` WRITE;
/*!40000 ALTER TABLE `delivery_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_payload`
--

DROP TABLE IF EXISTS `delivery_payload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_payload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `creation_time` datetime NOT NULL,
  `payload` mediumblob NOT NULL,
  `delivery_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_delivery_payload_task_id` (`task_id`),
  KEY `delivery_id` (`delivery_id`),
  CONSTRAINT `delivery_payload_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_payload`
--

LOCK TABLES `delivery_payload` WRITE;
/*!40000 ALTER TABLE `delivery_payload` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_payload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deployed_service`
--

DROP TABLE IF EXISTS `deployed_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deployed_service` (
  `deployment_time` datetime NOT NULL,
  `details` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `source` mediumblob,
  `source_path` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_hash` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_hash_method` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `server_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`server_id`,`service_id`),
  UNIQUE KEY `server_id` (`server_id`,`service_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `deployed_service_ibfk_1` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deployed_service_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deployed_service`
--

LOCK TABLES `deployed_service` WRITE;
/*!40000 ALTER TABLE `deployed_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `deployed_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deployment_package`
--

DROP TABLE IF EXISTS `deployment_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deployment_package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deployment_time` datetime NOT NULL,
  `details` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `payload_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `payload` mediumblob NOT NULL,
  `server_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_id` (`server_id`),
  CONSTRAINT `deployment_package_ibfk_1` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deployment_package`
--

LOCK TABLES `deployment_package` WRITE;
/*!40000 ALTER TABLE `deployment_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `deployment_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deployment_status`
--

DROP TABLE IF EXISTS `deployment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deployment_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_change_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `package_id` (`package_id`,`server_id`),
  KEY `server_id` (`server_id`),
  CONSTRAINT `deployment_status_ibfk_1` FOREIGN KEY (`package_id`) REFERENCES `deployment_package` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deployment_status_ibfk_2` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deployment_status`
--

LOCK TABLES `deployment_status` WRITE;
/*!40000 ALTER TABLE `deployment_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `deployment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_imap`
--

DROP TABLE IF EXISTS `email_imap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_imap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `host` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `timeout` int(11) NOT NULL,
  `debug_level` int(11) NOT NULL,
  `username` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `get_criteria` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `email_imap_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_imap`
--

LOCK TABLES `email_imap` WRITE;
/*!40000 ALTER TABLE `email_imap` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_imap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_smtp`
--

DROP TABLE IF EXISTS `email_smtp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_smtp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `host` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `timeout` int(11) NOT NULL,
  `is_debug` tinyint(1) NOT NULL,
  `username` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ping_address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `email_smtp_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_smtp`
--

LOCK TABLES `email_smtp` WRITE;
/*!40000 ALTER TABLE `email_smtp` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_smtp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_soap`
--

DROP TABLE IF EXISTS `http_soap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_soap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_internal` tinyint(1) NOT NULL,
  `connection` enum('channel','outgoing') COLLATE utf8_unicode_ci NOT NULL,
  `transport` enum('plain_http','soap') COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_path` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `method` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `soap_action` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `soap_version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data_format` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ping_method` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pool_size` int(11) DEFAULT NULL,
  `merge_url_params_req` tinyint(1) DEFAULT NULL,
  `url_params_pri` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `params_pri` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `audit_enabled` tinyint(1) NOT NULL,
  `audit_back_log` int(11) NOT NULL,
  `audit_max_payload` int(11) NOT NULL,
  `audit_repl_patt_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `serialization_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `timeout` int(11) NOT NULL,
  `sec_tls_ca_cert_id` int(11) DEFAULT NULL,
  `has_rbac` tinyint(1) NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `cluster_id` int(11) NOT NULL,
  `security_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`connection`,`transport`,`cluster_id`),
  UNIQUE KEY `url_path` (`url_path`,`host`,`connection`,`soap_action`,`cluster_id`),
  KEY `sec_tls_ca_cert_id` (`sec_tls_ca_cert_id`),
  KEY `service_id` (`service_id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `security_id` (`security_id`),
  CONSTRAINT `http_soap_ibfk_1` FOREIGN KEY (`sec_tls_ca_cert_id`) REFERENCES `sec_tls_ca_cert` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_ibfk_3` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_ibfk_4` FOREIGN KEY (`security_id`) REFERENCES `sec_base` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=522 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_soap`
--

LOCK TABLES `http_soap` WRITE;
/*!40000 ALTER TABLE `http_soap` DISABLE KEYS */;
INSERT INTO `http_soap` VALUES (1,'zato.security.wss.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.wss.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,1,1,2),(2,'zato.security.wss.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.wss.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,1,1,2),(3,'zato.security.apikey.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.apikey.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,2,1,2),(4,'zato.security.apikey.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.apikey.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,2,1,2),(5,'zato.cloud.openstack.swift.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.openstack.swift.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,3,1,2),(6,'zato.cloud.openstack.swift.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.openstack.swift.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,3,1,2),(7,'zato.service.configure-request-response',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.configure-request-response','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,4,1,2),(8,'zato.service.configure-request-response.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.configure-request-response',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,4,1,2),(9,'zato.email.imap.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,5,1,2),(10,'zato.email.imap.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,5,1,2),(11,'zato.security.tech-account.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,6,1,2),(12,'zato.security.tech-account.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,6,1,2),(13,'zato.security.tls.ca_cert.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.ca_cert.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,7,1,2),(14,'zato.security.tls.ca_cert.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.ca_cert.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,7,1,2),(15,'zato.pubsub.producers.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.producers.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,8,1,2),(16,'zato.pubsub.producers.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.producers.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,8,1,2),(17,'zato.server.message.json_pointer.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.json_pointer.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,9,1,2),(18,'zato.server.message.json_pointer.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.json_pointer.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,9,1,2),(19,'zato.helpers.input-logger',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.helpers.input-logger','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,10,1,2),(20,'zato.helpers.input-logger.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.helpers.input-logger',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,10,1,2),(21,'zato.service.upload-package',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.upload-package','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,11,1,2),(22,'zato.service.upload-package.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.upload-package',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,11,1,2),(23,'zato.pubsub.producers.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.producers.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,12,1,2),(24,'zato.pubsub.producers.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.producers.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,12,1,2),(25,'zato.kvdb.data-dict.dictionary.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,13,1,2),(26,'zato.kvdb.data-dict.dictionary.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,13,1,2),(27,'zato.notif.cloud.openstack.swift.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.openstack.swift.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,14,1,2),(28,'zato.notif.cloud.openstack.swift.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.openstack.swift.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,14,1,2),(29,'zato.channel.jms-wmq.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.jms-wmq.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,15,1,2),(30,'zato.channel.jms-wmq.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.jms-wmq.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,15,1,2),(31,'zato.security.tls.ca_cert.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.ca_cert.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,16,1,2),(32,'zato.security.tls.ca_cert.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.ca_cert.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,16,1,2),(33,'zato.security.oauth.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.oauth.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,17,1,2),(34,'zato.security.oauth.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.oauth.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,17,1,2),(35,'zato.http-soap.ping',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.http-soap.ping','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,18,1,2),(36,'zato.http-soap.ping.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.http-soap.ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,18,1,2),(37,'zato.kvdb.data-dict.translation.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,19,1,2),(38,'zato.kvdb.data-dict.translation.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,19,1,2),(39,'zato.outgoing.ftp.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.ftp.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,20,1,2),(40,'zato.outgoing.ftp.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.ftp.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,20,1,2),(41,'zato.outgoing.zmq.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.zmq.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,21,1,2),(42,'zato.outgoing.zmq.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.zmq.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,21,1,2),(43,'zato.security.openstack.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.openstack.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,22,1,2),(44,'zato.security.openstack.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.openstack.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,22,1,2),(45,'zato.helpers.sio-input-logger',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.helpers.sio-input-logger','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,23,1,2),(46,'zato.helpers.sio-input-logger.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.helpers.sio-input-logger',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,23,1,2),(47,'zato.hot_deploy.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.hot_deploy.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,24,1,2),(48,'zato.hot_deploy.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.hot_deploy.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,24,1,2),(49,'zato.stats.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,25,1,2),(50,'zato.stats.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,25,1,2),(51,'zato.pubsub.topics.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,26,1,2),(52,'zato.pubsub.topics.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,26,1,2),(53,'zato.scheduler.job.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,27,1,2),(54,'zato.scheduler.job.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,27,1,2),(55,'zato.service.get-deployment-info-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-deployment-info-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,28,1,2),(56,'zato.service.get-deployment-info-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-deployment-info-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,28,1,2),(57,'zato.scheduler.job.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,29,1,2),(58,'zato.scheduler.job.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,29,1,2),(59,'zato.definition.amqp.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,30,1,2),(60,'zato.definition.amqp.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,30,1,2),(61,'zato.security.openstack.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.openstack.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,31,1,2),(62,'zato.security.openstack.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.openstack.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,31,1,2),(63,'zato.security.tls.ca_cert.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.ca_cert.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,32,1,2),(64,'zato.security.tls.ca_cert.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.ca_cert.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,32,1,2),(65,'zato.pubsub.producers.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.producers.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,33,1,2),(66,'zato.pubsub.producers.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.producers.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,33,1,2),(67,'zato.pubsub.invoke-callbacks',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.invoke-callbacks','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,34,1,2),(68,'zato.pubsub.invoke-callbacks.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.invoke-callbacks',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,34,1,2),(69,'zato.pubsub.consumers.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.consumers.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,35,1,2),(70,'zato.pubsub.consumers.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.consumers.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,35,1,2),(71,'zato.helpers.echo',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.helpers.echo','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,36,1,2),(72,'zato.helpers.echo.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.helpers.echo',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,36,1,2),(73,'zato.email.imap.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,37,1,2),(74,'zato.email.imap.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,37,1,2),(75,'zato.channel.amqp.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.amqp.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,38,1,2),(76,'zato.channel.amqp.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.amqp.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,38,1,2),(77,'zato.security.apikey.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.apikey.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,39,1,2),(78,'zato.security.apikey.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.apikey.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,39,1,2),(79,'zato.security.rbac.role.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,40,1,2),(80,'zato.security.rbac.role.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,40,1,2),(81,'zato.security.tech-account.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,41,1,2),(82,'zato.security.tech-account.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,41,1,2),(83,'zato.cloud.aws.s3.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.aws.s3.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,42,1,2),(84,'zato.cloud.aws.s3.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.aws.s3.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,42,1,2),(85,'zato.http-soap.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.http-soap.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,43,1,2),(86,'zato.http-soap.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.http-soap.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,43,1,2),(87,'zato.email.smtp.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,44,1,2),(88,'zato.email.smtp.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,44,1,2),(89,'zato.security.basic-auth.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.basic-auth.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,45,1,2),(90,'zato.security.basic-auth.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.basic-auth.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,45,1,2),(91,'zato.kvdb.data-dict.dictionary.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,46,1,2),(92,'zato.kvdb.data-dict.dictionary.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,46,1,2),(93,'zato.search.es.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.es.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,47,1,2),(94,'zato.search.es.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.es.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,47,1,2),(95,'zato.service.set-wsdl',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.set-wsdl','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,48,1,2),(96,'zato.service.set-wsdl.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.set-wsdl',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,48,1,2),(97,'zato.security.aws.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.aws.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,49,1,2),(98,'zato.security.aws.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.aws.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,49,1,2),(99,'zato.pubsub.producers.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.producers.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,50,1,2),(100,'zato.pubsub.producers.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.producers.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,50,1,2),(101,'zato.service.get-wsdl.soap',1,1,'channel','plain_http',NULL,'/zato/wsdl',NULL,'',NULL,NULL,NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,51,1,NULL),(102,'zato.service.get-wsdl',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-wsdl','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,51,1,2),(103,'zato.service.get-wsdl.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-wsdl',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,51,1,2),(104,'zato.pubsub.move-to-target-queues',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.move-to-target-queues','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,52,1,2),(105,'zato.pubsub.move-to-target-queues.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.move-to-target-queues',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,52,1,2),(106,'zato.search.solr.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.solr.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,53,1,2),(107,'zato.search.solr.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.solr.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,53,1,2),(108,'zato.outgoing.jms-wmq.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.jms-wmq.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,54,1,2),(109,'zato.outgoing.jms-wmq.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.jms-wmq.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,54,1,2),(110,'zato.stats.summary.get-summary-by-month',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.summary.get-summary-by-month','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,55,1,2),(111,'zato.stats.summary.get-summary-by-month.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.summary.get-summary-by-month',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,55,1,2),(112,'zato.security.rbac.role.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,56,1,2),(113,'zato.security.rbac.role.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,56,1,2),(114,'zato.security.oauth.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.oauth.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,57,1,2),(115,'zato.security.oauth.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.oauth.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,57,1,2),(116,'zato.stats.summary.get-summary-by-year',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.summary.get-summary-by-year','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,58,1,2),(117,'zato.stats.summary.get-summary-by-year.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.summary.get-summary-by-year',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,58,1,2),(118,'zato.outgoing.sql.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,59,1,2),(119,'zato.outgoing.sql.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,59,1,2),(120,'zato.pubsub.producers.get-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.producers.get-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,60,1,2),(121,'zato.pubsub.producers.get-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.producers.get-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,60,1,2),(122,'zato.search.es.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.es.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,61,1,2),(123,'zato.search.es.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.es.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,61,1,2),(124,'zato.pubsub.message.create.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.message.create.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,62,1,2),(125,'zato.pubsub.message.create.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.message.create.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,62,1,2),(126,'zato.security.tls.ca_cert.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.ca_cert.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,63,1,2),(127,'zato.security.tls.ca_cert.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.ca_cert.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,63,1,2),(128,'zato.server.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,64,1,2),(129,'zato.server.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,64,1,2),(130,'zato.definition.jms-wmq.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.jms-wmq.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,65,1,2),(131,'zato.definition.jms-wmq.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.jms-wmq.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,65,1,2),(132,'zato.security.tls.key_cert.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.key_cert.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,66,1,2),(133,'zato.security.tls.key_cert.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.key_cert.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,66,1,2),(134,'zato.security.rbac.client-role.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.client-role.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,67,1,2),(135,'zato.security.rbac.client-role.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.client-role.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,67,1,2),(136,'zato.server.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,68,1,2),(137,'zato.server.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,68,1,2),(138,'zato.definition.amqp.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,69,1,2),(139,'zato.definition.amqp.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,69,1,2),(140,'zato.outgoing.ftp.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.ftp.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,70,1,2),(141,'zato.outgoing.ftp.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.ftp.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,70,1,2),(142,'zato.security.xpath.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.xpath.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,71,1,2),(143,'zato.security.xpath.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.xpath.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,71,1,2),(144,'zato.outgoing.sql.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,72,1,2),(145,'zato.outgoing.sql.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,72,1,2),(146,'zato.server.message.json_pointer.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.json_pointer.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,73,1,2),(147,'zato.server.message.json_pointer.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.json_pointer.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,73,1,2),(148,'zato.pubsub.consumers.get-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.consumers.get-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,74,1,2),(149,'zato.pubsub.consumers.get-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.consumers.get-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,74,1,2),(150,'zato.security.rbac.client-role.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.client-role.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,75,1,2),(151,'zato.security.rbac.client-role.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.client-role.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,75,1,2),(152,'zato.outgoing.sql.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,76,1,2),(153,'zato.outgoing.sql.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,76,1,2),(154,'zato.definition.cassandra.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.cassandra.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,77,1,2),(155,'zato.definition.cassandra.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.cassandra.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,77,1,2),(156,'zato.service.get-by-name',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-by-name','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,78,1,2),(157,'zato.service.get-by-name.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-by-name',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,78,1,2),(158,'zato.security.rbac.permission.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.permission.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,79,1,2),(159,'zato.security.rbac.permission.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.permission.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,79,1,2),(160,'zato.info.get-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.info.get-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,80,1,2),(161,'zato.info.get-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.info.get-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,80,1,2),(162,'zato.outgoing.odoo.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,81,1,2),(163,'zato.outgoing.odoo.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,81,1,2),(164,'zato.outgoing.zmq.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.zmq.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,82,1,2),(165,'zato.outgoing.zmq.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.zmq.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,82,1,2),(166,'zato.security.rbac.role.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,83,1,2),(167,'zato.security.rbac.role.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,83,1,2),(168,'zato.outgoing.ftp.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.ftp.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,84,1,2),(169,'zato.outgoing.ftp.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.ftp.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,84,1,2),(170,'zato.definition.amqp.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,85,1,2),(171,'zato.definition.amqp.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,85,1,2),(172,'zato.email.imap.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,86,1,2),(173,'zato.email.imap.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,86,1,2),(174,'zato.definition.amqp.get-by-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.get-by-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,87,1,2),(175,'zato.definition.amqp.get-by-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.get-by-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,87,1,2),(176,'zato.outgoing.odoo.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,88,1,2),(177,'zato.outgoing.odoo.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,88,1,2),(178,'zato.server.message.namespace.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.namespace.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,89,1,2),(179,'zato.server.message.namespace.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.namespace.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,89,1,2),(180,'zato.scheduler.job.execute',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.execute','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,90,1,2),(181,'zato.scheduler.job.execute.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.execute',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,90,1,2),(182,'zato.email.imap.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,91,1,2),(183,'zato.email.imap.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,91,1,2),(184,'zato.cloud.aws.s3.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.aws.s3.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,92,1,2),(185,'zato.cloud.aws.s3.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.aws.s3.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,92,1,2),(186,'zato.kvdb.data-dict.translation.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,93,1,2),(187,'zato.kvdb.data-dict.translation.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,93,1,2),(188,'zato.security.openstack.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.openstack.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,94,1,2),(189,'zato.security.openstack.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.openstack.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,94,1,2),(190,'zato.security.tech-account.get-by-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.get-by-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,95,1,2),(191,'zato.security.tech-account.get-by-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.get-by-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,95,1,2),(192,'zato.cloud.aws.s3.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.aws.s3.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,96,1,2),(193,'zato.cloud.aws.s3.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.aws.s3.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,96,1,2),(194,'zato.security.openstack.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.openstack.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,97,1,2),(195,'zato.security.openstack.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.openstack.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,97,1,2),(196,'zato.definition.cassandra.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.cassandra.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,98,1,2),(197,'zato.definition.cassandra.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.cassandra.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,98,1,2),(198,'zato.security.wss.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.wss.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,99,1,2),(199,'zato.security.wss.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.wss.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,99,1,2),(200,'zato.definition.cassandra.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.cassandra.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,100,1,2),(201,'zato.definition.cassandra.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.cassandra.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,100,1,2),(202,'zato.outgoing.amqp.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.amqp.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,101,1,2),(203,'zato.outgoing.amqp.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.amqp.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,101,1,2),(204,'zato.service.slow-response.get',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.slow-response.get','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,102,1,2),(205,'zato.service.slow-response.get.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.slow-response.get',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,102,1,2),(206,'zato.query.cassandra.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.query.cassandra.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,103,1,2),(207,'zato.query.cassandra.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.query.cassandra.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,103,1,2),(208,'zato.pubsub.topics.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,104,1,2),(209,'zato.pubsub.topics.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,104,1,2),(210,'zato.email.smtp.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,105,1,2),(211,'zato.email.smtp.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,105,1,2),(212,'zato.http-soap.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.http-soap.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,106,1,2),(213,'zato.http-soap.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.http-soap.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,106,1,2),(214,'zato.kvdb.data-dict.translation.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,107,1,2),(215,'zato.kvdb.data-dict.translation.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,107,1,2),(216,'zato.pubsub.message.create.get',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.message.create.get','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,108,1,2),(217,'zato.pubsub.message.create.get.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.message.create.get',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,108,1,2),(218,'zato.security.rbac.permission.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.permission.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,109,1,2),(219,'zato.security.rbac.permission.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.permission.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,109,1,2),(220,'zato.security.aws.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.aws.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,110,1,2),(221,'zato.security.aws.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.aws.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,110,1,2),(222,'zato.security.oauth.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.oauth.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,111,1,2),(223,'zato.security.oauth.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.oauth.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,111,1,2),(224,'zato.outgoing.amqp.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.amqp.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,112,1,2),(225,'zato.outgoing.amqp.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.amqp.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,112,1,2),(226,'zato.outgoing.sql.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,113,1,2),(227,'zato.outgoing.sql.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,113,1,2),(228,'zato.scheduler.job.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,114,1,2),(229,'zato.scheduler.job.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,114,1,2),(230,'zato.service.get-channel-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-channel-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,115,1,2),(231,'zato.service.get-channel-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-channel-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,115,1,2),(232,'zato.security.basic-auth.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.basic-auth.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,116,1,2),(233,'zato.security.basic-auth.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.basic-auth.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,116,1,2),(234,'zato.security.xpath.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.xpath.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,117,1,2),(235,'zato.security.xpath.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.xpath.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,117,1,2),(236,'zato.kvdb.remote-command.execute',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.remote-command.execute','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,118,1,2),(237,'zato.kvdb.remote-command.execute.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.remote-command.execute',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,118,1,2),(238,'zato.outgoing.odoo.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,119,1,2),(239,'zato.outgoing.odoo.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,119,1,2),(240,'zato.security.aws.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.aws.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,120,1,2),(241,'zato.security.aws.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.aws.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,120,1,2),(242,'zato.kvdb.data-dict.impexp.import',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.impexp.import','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,121,1,2),(243,'zato.kvdb.data-dict.impexp.import.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.impexp.import',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,121,1,2),(244,'zato.outgoing.zmq.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.zmq.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,122,1,2),(245,'zato.outgoing.zmq.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.zmq.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,122,1,2),(246,'zato.security.rbac.permission.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.permission.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,123,1,2),(247,'zato.security.rbac.permission.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.permission.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,123,1,2),(248,'zato.definition.jms-wmq.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.jms-wmq.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,124,1,2),(249,'zato.definition.jms-wmq.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.jms-wmq.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,124,1,2),(250,'zato.kvdb.data-dict.translation.get-last-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.get-last-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,125,1,2),(251,'zato.kvdb.data-dict.translation.get-last-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.get-last-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,125,1,2),(252,'zato.security.rbac.permission.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.permission.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,126,1,2),(253,'zato.security.rbac.permission.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.permission.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,126,1,2),(254,'zato.cloud.aws.s3.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.aws.s3.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,127,1,2),(255,'zato.cloud.aws.s3.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.aws.s3.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,127,1,2),(256,'zato.definition.jms-wmq.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.jms-wmq.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,128,1,2),(257,'zato.definition.jms-wmq.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.jms-wmq.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,128,1,2),(258,'zato.stats.summary.get-summary-by-day',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.summary.get-summary-by-day','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,129,1,2),(259,'zato.stats.summary.get-summary-by-day.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.summary.get-summary-by-day',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,129,1,2),(260,'zato.security.rbac.role-permission.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role-permission.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,130,1,2),(261,'zato.security.rbac.role-permission.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role-permission.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,130,1,2),(262,'zato.scheduler.job.get-by-name',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.get-by-name','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,131,1,2),(263,'zato.scheduler.job.get-by-name.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.get-by-name',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,131,1,2),(264,'zato.stats.summary.get-summary-by-range',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.summary.get-summary-by-range','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,132,1,2),(265,'zato.stats.summary.get-summary-by-range.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.summary.get-summary-by-range',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,132,1,2),(266,'zato.pubsub.delete-expired',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.delete-expired','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,133,1,2),(267,'zato.pubsub.delete-expired.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.delete-expired',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,133,1,2),(268,'zato.security.wss.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.wss.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,134,1,2),(269,'zato.security.wss.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.wss.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,134,1,2),(270,'zato.channel.amqp.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.amqp.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,135,1,2),(271,'zato.channel.amqp.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.amqp.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,135,1,2),(272,'zato.server.message.namespace.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.namespace.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,136,1,2),(273,'zato.server.message.namespace.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.namespace.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,136,1,2),(274,'zato.channel.zmq.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.zmq.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,137,1,2),(275,'zato.channel.zmq.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.zmq.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,137,1,2),(276,'zato.security.xpath.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.xpath.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,138,1,2),(277,'zato.security.xpath.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.xpath.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,138,1,2),(278,'zato.server.message.xpath.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.xpath.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,139,1,2),(279,'zato.server.message.xpath.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.xpath.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,139,1,2),(280,'zato.definition.cassandra.get-by-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.cassandra.get-by-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,140,1,2),(281,'zato.definition.cassandra.get-by-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.cassandra.get-by-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,140,1,2),(282,'zato.kvdb.data-dict.dictionary.get-system-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.get-system-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,141,1,2),(283,'zato.kvdb.data-dict.dictionary.get-system-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.get-system-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,141,1,2),(284,'zato.pubsub.message.create.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.message.create.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,142,1,2),(285,'zato.pubsub.message.create.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.message.create.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,142,1,2),(286,'zato.pubsub.consumers.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.consumers.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,143,1,2),(287,'zato.pubsub.consumers.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.consumers.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,143,1,2),(288,'zato.kvdb.data-dict.dictionary.get-value-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.get-value-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,144,1,2),(289,'zato.kvdb.data-dict.dictionary.get-value-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.get-value-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,144,1,2),(290,'zato.outgoing.sql.ping',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.ping','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,145,1,2),(291,'zato.outgoing.sql.ping.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,145,1,2),(292,'zato.security.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,146,1,2),(293,'zato.security.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,146,1,2),(294,'zato.outgoing.sql.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.sql.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,147,1,2),(295,'zato.outgoing.sql.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.sql.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,147,1,2),(296,'zato.cloud.openstack.swift.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.openstack.swift.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,148,1,2),(297,'zato.cloud.openstack.swift.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.openstack.swift.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,148,1,2),(298,'zato.security.apikey.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.apikey.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,149,1,2),(299,'zato.security.apikey.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.apikey.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,149,1,2),(300,'zato.search.solr.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.solr.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,150,1,2),(301,'zato.search.solr.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.solr.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,150,1,2),(302,'zato.kvdb.data-dict.dictionary.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,151,1,2),(303,'zato.kvdb.data-dict.dictionary.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,151,1,2),(304,'zato.pubsub.consumers.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.consumers.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,152,1,2),(305,'zato.pubsub.consumers.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.consumers.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,152,1,2),(306,'zato.http-soap.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.http-soap.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,153,1,2),(307,'zato.http-soap.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.http-soap.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,153,1,2),(308,'zato.definition.jms-wmq.get-by-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.jms-wmq.get-by-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,154,1,2),(309,'zato.definition.jms-wmq.get-by-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.jms-wmq.get-by-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,154,1,2),(310,'zato.kvdb.data-dict.translation.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,155,1,2),(311,'zato.kvdb.data-dict.translation.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,155,1,2),(312,'zato.security.basic-auth.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.basic-auth.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,156,1,2),(313,'zato.security.basic-auth.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.basic-auth.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,156,1,2),(314,'zato.definition.amqp.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,157,1,2),(315,'zato.definition.amqp.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,157,1,2),(316,'zato.security.rbac.client-role.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.client-role.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,158,1,2),(317,'zato.security.rbac.client-role.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.client-role.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,158,1,2),(318,'zato.service.get-source-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-source-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,159,1,2),(319,'zato.service.get-source-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-source-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,159,1,2),(320,'zato.security.rbac.role-permission.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role-permission.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,160,1,2),(321,'zato.security.rbac.role-permission.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role-permission.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,160,1,2),(322,'zato.security.tech-account.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,161,1,2),(323,'zato.security.tech-account.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,161,1,2),(324,'zato.server.message.namespace.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.namespace.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,162,1,2),(325,'zato.server.message.namespace.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.namespace.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,162,1,2),(326,'zato.search.solr.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.solr.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,163,1,2),(327,'zato.search.solr.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.solr.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,163,1,2),(328,'zato.notif.cloud.sql.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.sql.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,164,1,2),(329,'zato.notif.cloud.sql.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.sql.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,164,1,2),(330,'zato.security.rbac.role-permission.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role-permission.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,165,1,2),(331,'zato.security.rbac.role-permission.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role-permission.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,165,1,2),(332,'zato.query.cassandra.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.query.cassandra.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,166,1,2),(333,'zato.query.cassandra.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.query.cassandra.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,166,1,2),(334,'zato.outgoing.amqp.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.amqp.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,167,1,2),(335,'zato.outgoing.amqp.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.amqp.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,167,1,2),(336,'zato.security.tls.ca_cert.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.ca_cert.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,168,1,2),(337,'zato.security.tls.ca_cert.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.ca_cert.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,168,1,2),(338,'zato.security.oauth.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.oauth.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,169,1,2),(339,'zato.security.oauth.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.oauth.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,169,1,2),(340,'zato.server.get-by-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.get-by-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,170,1,2),(341,'zato.server.get-by-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.get-by-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,170,1,2),(342,'zato.security.tech-account.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,171,1,2),(343,'zato.security.tech-account.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,171,1,2),(344,'zato.server.message.namespace.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.namespace.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,172,1,2),(345,'zato.server.message.namespace.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.namespace.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,172,1,2),(346,'zato.definition.amqp.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.amqp.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,173,1,2),(347,'zato.definition.amqp.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.amqp.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,173,1,2),(348,'zato.server.message.json_pointer.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.json_pointer.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,174,1,2),(349,'zato.server.message.json_pointer.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.json_pointer.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,174,1,2),(350,'zato.channel.jms-wmq.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.jms-wmq.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,175,1,2),(351,'zato.channel.jms-wmq.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.jms-wmq.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,175,1,2),(352,'zato.pubsub.topics.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,176,1,2),(353,'zato.pubsub.topics.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,176,1,2),(354,'zato.channel.amqp.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.amqp.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,177,1,2),(355,'zato.channel.amqp.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.amqp.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,177,1,2),(356,'zato.outgoing.zmq.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.zmq.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,178,1,2),(357,'zato.outgoing.zmq.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.zmq.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,178,1,2),(358,'zato.stats.summary.get-summary-by-week',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.summary.get-summary-by-week','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,179,1,2),(359,'zato.stats.summary.get-summary-by-week.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.summary.get-summary-by-week',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,179,1,2),(360,'zato.security.xpath.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.xpath.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,180,1,2),(361,'zato.security.xpath.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.xpath.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,180,1,2),(362,'zato.pubsub.topics.get-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.get-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,181,1,2),(363,'zato.pubsub.topics.get-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.get-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,181,1,2),(364,'zato.channel.jms-wmq.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.jms-wmq.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,182,1,2),(365,'zato.channel.jms-wmq.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.jms-wmq.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,182,1,2),(366,'zato.outgoing.jms-wmq.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.jms-wmq.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,183,1,2),(367,'zato.outgoing.jms-wmq.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.jms-wmq.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,183,1,2),(368,'zato.outgoing.ftp.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.ftp.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,184,1,2),(369,'zato.outgoing.ftp.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.ftp.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,184,1,2),(370,'zato.security.basic-auth.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.basic-auth.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,185,1,2),(371,'zato.security.basic-auth.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.basic-auth.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,185,1,2),(372,'zato.http-soap.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.http-soap.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,186,1,2),(373,'zato.http-soap.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.http-soap.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,186,1,2),(374,'zato.search.es.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.es.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,187,1,2),(375,'zato.search.es.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.es.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,187,1,2),(376,'zato.service.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,188,1,2),(377,'zato.service.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,188,1,2),(378,'zato.security.aws.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.aws.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,189,1,2),(379,'zato.security.aws.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.aws.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,189,1,2),(380,'zato.outgoing.jms-wmq.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.jms-wmq.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,190,1,2),(381,'zato.outgoing.jms-wmq.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.jms-wmq.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,190,1,2),(382,'zato.service.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,191,1,2),(383,'zato.service.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,191,1,2),(384,'zato.server.message.xpath.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.xpath.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,192,1,2),(385,'zato.server.message.xpath.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.xpath.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,192,1,2),(386,'zato.security.apikey.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.apikey.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,193,1,2),(387,'zato.security.apikey.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.apikey.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,193,1,2),(388,'zato.outgoing.odoo.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,194,1,2),(389,'zato.outgoing.odoo.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,194,1,2),(390,'zato.channel.zmq.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.zmq.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,195,1,2),(391,'zato.channel.zmq.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.zmq.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,195,1,2),(392,'zato.channel.zmq.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.zmq.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,196,1,2),(393,'zato.channel.zmq.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.zmq.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,196,1,2),(394,'zato.server.message.xpath.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.xpath.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,197,1,2),(395,'zato.server.message.xpath.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.xpath.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,197,1,2),(396,'zato.search.solr.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.solr.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,198,1,2),(397,'zato.search.solr.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.solr.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,198,1,2),(398,'zato.security.tls.key_cert.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.key_cert.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,199,1,2),(399,'zato.security.tls.key_cert.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.key_cert.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,199,1,2),(400,'zato.pubsub.consumers.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.consumers.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,200,1,2),(401,'zato.pubsub.consumers.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.consumers.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,200,1,2),(402,'zato.service.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,201,1,2),(403,'zato.service.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,201,1,2),(404,'zato.info.get-server-info',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.info.get-server-info','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,202,1,2),(405,'zato.info.get-server-info.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.info.get-server-info',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,202,1,2),(406,'zato.cloud.openstack.swift.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.openstack.swift.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,203,1,2),(407,'zato.cloud.openstack.swift.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.openstack.swift.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,203,1,2),(408,'zato.channel.zmq.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.zmq.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,204,1,2),(409,'zato.channel.zmq.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.zmq.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,204,1,2),(410,'zato.email.imap.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,205,1,2),(411,'zato.email.imap.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,205,1,2),(412,'zato.outgoing.jms-wmq.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.jms-wmq.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,206,1,2),(413,'zato.outgoing.jms-wmq.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.jms-wmq.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,206,1,2),(414,'zato.security.wss.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.wss.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,207,1,2),(415,'zato.security.wss.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.wss.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,207,1,2),(416,'zato.stats.trends.get-trends',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.trends.get-trends','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,208,1,2),(417,'zato.stats.trends.get-trends.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.trends.get-trends',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,208,1,2),(418,'zato.pubsub.rest',1,1,'channel','plain_http',NULL,'/zato/pubsub/{item_type}/{item}/',NULL,'',NULL,NULL,NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,209,1,NULL),(419,'zato.pubsub.rest-handler',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.rest-handler','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,209,1,2),(420,'zato.pubsub.rest-handler.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.rest-handler',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,209,1,2),(421,'zato.service.has-wsdl',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.has-wsdl','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,210,1,2),(422,'zato.service.has-wsdl.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.has-wsdl',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,210,1,2),(423,'zato.scheduler.job.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.scheduler.job.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,211,1,2),(424,'zato.scheduler.job.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.scheduler.job.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,211,1,2),(425,'zato.email.smtp.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,212,1,2),(426,'zato.email.smtp.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,212,1,2),(427,'zato.kvdb.data-dict.dictionary.get-key-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.get-key-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,213,1,2),(428,'zato.kvdb.data-dict.dictionary.get-key-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.get-key-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,213,1,2),(429,'zato.email.smtp.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,214,1,2),(430,'zato.email.smtp.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,214,1,2),(431,'zato.cloud.openstack.swift.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.cloud.openstack.swift.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,215,1,2),(432,'zato.cloud.openstack.swift.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.cloud.openstack.swift.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,215,1,2),(433,'zato.outgoing.ftp.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.ftp.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,216,1,2),(434,'zato.outgoing.ftp.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.ftp.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,216,1,2),(435,'zato.kvdb.data-dict.dictionary.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,217,1,2),(436,'zato.kvdb.data-dict.dictionary.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,217,1,2),(437,'zato.security.basic-auth.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.basic-auth.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,218,1,2),(438,'zato.security.basic-auth.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.basic-auth.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,218,1,2),(439,'zato.definition.jms-wmq.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.jms-wmq.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,219,1,2),(440,'zato.definition.jms-wmq.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.jms-wmq.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,219,1,2),(441,'zato.security.tech-account.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tech-account.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,220,1,2),(442,'zato.security.tech-account.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tech-account.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,220,1,2),(443,'zato.notif.cloud.openstack.swift.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.openstack.swift.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,221,1,2),(444,'zato.notif.cloud.openstack.swift.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.openstack.swift.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,221,1,2),(445,'zato.email.imap.ping',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.imap.ping','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,222,1,2),(446,'zato.email.imap.ping.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.imap.ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,222,1,2),(447,'zato.security.aws.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.aws.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,223,1,2),(448,'zato.security.aws.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.aws.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,223,1,2),(449,'zato.security.apikey.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.apikey.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,224,1,2),(450,'zato.security.apikey.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.apikey.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,224,1,2),(451,'zato.server.message.json_pointer.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.json_pointer.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,225,1,2),(452,'zato.server.message.json_pointer.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.json_pointer.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,225,1,2),(453,'zato.security.tls.key_cert.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.key_cert.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,226,1,2),(454,'zato.security.tls.key_cert.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.key_cert.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,226,1,2),(455,'zato.stats.get-by-service',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.stats.get-by-service','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,227,1,2),(456,'zato.stats.get-by-service.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.stats.get-by-service',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,227,1,2),(457,'zato.query.cassandra.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.query.cassandra.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,228,1,2),(458,'zato.query.cassandra.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.query.cassandra.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,228,1,2),(459,'zato.notif.cloud.sql.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.sql.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,229,1,2),(460,'zato.notif.cloud.sql.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.sql.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,229,1,2),(461,'zato.notif.cloud.sql.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.sql.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,230,1,2),(462,'zato.notif.cloud.sql.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.sql.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,230,1,2),(463,'zato.channel.jms-wmq.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.jms-wmq.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,231,1,2),(464,'zato.channel.jms-wmq.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.jms-wmq.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,231,1,2),(465,'zato.outgoing.amqp.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.amqp.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,232,1,2),(466,'zato.outgoing.amqp.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.amqp.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,232,1,2),(467,'zato.notif.cloud.sql.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.sql.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,233,1,2),(468,'zato.notif.cloud.sql.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.sql.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,233,1,2),(469,'zato.definition.cassandra.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.definition.cassandra.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,234,1,2),(470,'zato.definition.cassandra.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.definition.cassandra.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,234,1,2),(471,'zato.security.tls.key_cert.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.tls.key_cert.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,235,1,2),(472,'zato.security.tls.key_cert.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.tls.key_cert.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,235,1,2),(473,'zato.security.wss.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.wss.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,236,1,2),(474,'zato.security.wss.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.wss.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,236,1,2),(475,'zato.security.xpath.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.xpath.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,237,1,2),(476,'zato.security.xpath.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.xpath.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,237,1,2),(477,'zato.pubsub.topics.publish',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.publish','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,238,1,2),(478,'zato.pubsub.topics.publish.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.publish',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,238,1,2),(479,'zato.email.smtp.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,239,1,2),(480,'zato.email.smtp.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,239,1,2),(481,'zato.service.get-request-response',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.get-request-response','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,240,1,2),(482,'zato.service.get-request-response.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.get-request-response',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,240,1,2),(483,'zato.pubsub.topics.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.pubsub.topics.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,241,1,2),(484,'zato.pubsub.topics.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.pubsub.topics.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,241,1,2),(485,'zato.kvdb.data-dict.translation.translate',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.translation.translate','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,242,1,2),(486,'zato.kvdb.data-dict.translation.translate.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.translation.translate',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,242,1,2),(487,'zato.security.openstack.change-password',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.openstack.change-password','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,243,1,2),(488,'zato.security.openstack.change-password.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.openstack.change-password',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,243,1,2),(489,'zato.notif.cloud.openstack.swift.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.openstack.swift.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,244,1,2),(490,'zato.notif.cloud.openstack.swift.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.openstack.swift.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,244,1,2),(491,'zato.outgoing.odoo.delete',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.delete','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,245,1,2),(492,'zato.outgoing.odoo.delete.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.delete',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,245,1,2),(493,'zato.server.message.xpath.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.server.message.xpath.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,246,1,2),(494,'zato.server.message.xpath.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.server.message.xpath.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,246,1,2),(495,'zato.security.oauth.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.oauth.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,247,1,2),(496,'zato.security.oauth.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.oauth.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,247,1,2),(497,'zato.notif.cloud.openstack.swift.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.notif.cloud.openstack.swift.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,248,1,2),(498,'zato.notif.cloud.openstack.swift.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.notif.cloud.openstack.swift.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,248,1,2),(499,'zato.search.es.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.search.es.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,249,1,2),(500,'zato.search.es.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.search.es.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,249,1,2),(501,'zato.security.rbac.role.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.security.rbac.role.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,250,1,2),(502,'zato.security.rbac.role.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.security.rbac.role.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,250,1,2),(503,'zato.service.slow-response.get-list',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.slow-response.get-list','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,251,1,2),(504,'zato.service.slow-response.get-list.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.slow-response.get-list',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,251,1,2),(505,'zato.email.smtp.ping',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.email.smtp.ping','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,252,1,2),(506,'zato.email.smtp.ping.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.email.smtp.ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,252,1,2),(507,'admin.invoke.json',1,1,'channel','plain_http',NULL,'/zato/admin/invoke',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,253,1,1),(508,'zato.service.invoke',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.service.invoke','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,253,1,2),(509,'zato.service.invoke.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.service.invoke',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,253,1,2),(510,'zato.kvdb.data-dict.dictionary.get-last-id',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.kvdb.data-dict.dictionary.get-last-id','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,254,1,2),(511,'zato.kvdb.data-dict.dictionary.get-last-id.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.kvdb.data-dict.dictionary.get-last-id',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,254,1,2),(512,'zato.outgoing.odoo.ping',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.outgoing.odoo.ping','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,255,1,2),(513,'zato.outgoing.odoo.ping.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.outgoing.odoo.ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,255,1,2),(514,'zato.channel.amqp.edit',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.channel.amqp.edit','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,256,1,2),(515,'zato.channel.amqp.edit.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.channel.amqp.edit',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,256,1,2),(516,'zato.query.cassandra.create',1,1,'channel','soap',NULL,'/zato/soap',NULL,'zato.query.cassandra.create','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,257,1,2),(517,'zato.query.cassandra.create.json',1,1,'channel','plain_http',NULL,'/zato/json/zato.query.cassandra.create',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,257,1,2),(518,'zato.ping',1,1,'channel','plain_http',NULL,'/zato/ping',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,258,1,NULL),(519,'zato.ping.plain_http.basic_auth',1,1,'channel','plain_http',NULL,'/zato/ping.plain_http.basic_auth',NULL,'',NULL,'json',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,258,1,3),(520,'zato.ping.soap.basic_auth',1,1,'channel','soap',NULL,'/zato/ping.soap.basic_auth',NULL,'zato.ping.soap.basic_auth','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,258,1,4),(521,'zato.ping.soap.wss.clear_text',1,1,'channel','soap',NULL,'/zato/ping.soap.wss.clear_text',NULL,'zato.ping.soap.basic_auth','1.1','xml',NULL,NULL,1,'qs-over-path','channel-params-over-msg',0,1440,0,'json-pointer','suds',10,NULL,0,258,1,5);
/*!40000 ALTER TABLE `http_soap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_soap_au_rpl_p_jp`
--

DROP TABLE IF EXISTS `http_soap_au_rpl_p_jp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_soap_au_rpl_p_jp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conn_id` int(11) NOT NULL,
  `pattern_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `conn_id` (`conn_id`,`pattern_id`),
  KEY `pattern_id` (`pattern_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `http_soap_au_rpl_p_jp_ibfk_1` FOREIGN KEY (`conn_id`) REFERENCES `http_soap` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_au_rpl_p_jp_ibfk_2` FOREIGN KEY (`pattern_id`) REFERENCES `msg_json_pointer` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_au_rpl_p_jp_ibfk_3` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_soap_au_rpl_p_jp`
--

LOCK TABLES `http_soap_au_rpl_p_jp` WRITE;
/*!40000 ALTER TABLE `http_soap_au_rpl_p_jp` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_soap_au_rpl_p_jp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_soap_au_rpl_p_xp`
--

DROP TABLE IF EXISTS `http_soap_au_rpl_p_xp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_soap_au_rpl_p_xp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conn_id` int(11) NOT NULL,
  `pattern_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `conn_id` (`conn_id`,`pattern_id`),
  KEY `pattern_id` (`pattern_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `http_soap_au_rpl_p_xp_ibfk_1` FOREIGN KEY (`conn_id`) REFERENCES `http_soap` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_au_rpl_p_xp_ibfk_2` FOREIGN KEY (`pattern_id`) REFERENCES `msg_xpath` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_au_rpl_p_xp_ibfk_3` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_soap_au_rpl_p_xp`
--

LOCK TABLES `http_soap_au_rpl_p_xp` WRITE;
/*!40000 ALTER TABLE `http_soap_au_rpl_p_xp` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_soap_au_rpl_p_xp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_soap_audit`
--

DROP TABLE IF EXISTS `http_soap_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_soap_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cid` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `transport` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `connection` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `req_time` datetime NOT NULL,
  `resp_time` datetime DEFAULT NULL,
  `user_token` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoke_ok` tinyint(1) DEFAULT NULL,
  `auth_ok` tinyint(1) DEFAULT NULL,
  `remote_addr` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `req_headers` blob,
  `req_payload` blob,
  `resp_headers` blob,
  `resp_payload` blob,
  `cluster_id` int(11) NOT NULL,
  `conn_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `conn_id` (`conn_id`),
  KEY `ix_http_soap_audit_remote_addr` (`remote_addr`),
  KEY `ix_http_soap_audit_transport` (`transport`),
  KEY `ix_http_soap_audit_cid` (`cid`),
  KEY `ix_http_soap_audit_user_token` (`user_token`),
  KEY `ix_http_soap_audit_connection` (`connection`),
  KEY `ix_http_soap_audit_name` (`name`),
  CONSTRAINT `http_soap_audit_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE,
  CONSTRAINT `http_soap_audit_ibfk_2` FOREIGN KEY (`conn_id`) REFERENCES `http_soap` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_soap_audit`
--

LOCK TABLES `http_soap_audit` WRITE;
/*!40000 ALTER TABLE `http_soap_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_soap_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_state`
--

DROP TABLE IF EXISTS `install_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) NOT NULL,
  `install_time` datetime NOT NULL,
  `source_host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `source_user` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_state`
--

LOCK TABLES `install_state` WRITE;
/*!40000 ALTER TABLE `install_state` DISABLE KEYS */;
INSERT INTO `install_state` VALUES (1,1,'2018-01-25 02:59:13','zato','dmw');
/*!40000 ALTER TABLE `install_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `job_type` enum('one_time','interval_based','cron_style') COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `extra` mediumblob,
  `cluster_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `job_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_cron_style`
--

DROP TABLE IF EXISTS `job_cron_style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_cron_style` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cron_definition` varchar(4000) COLLATE utf8_unicode_ci NOT NULL,
  `job_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`),
  CONSTRAINT `job_cron_style_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_cron_style`
--

LOCK TABLES `job_cron_style` WRITE;
/*!40000 ALTER TABLE `job_cron_style` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_cron_style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_interval_based`
--

DROP TABLE IF EXISTS `job_interval_based`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_interval_based` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weeks` int(11) DEFAULT NULL,
  `days` int(11) DEFAULT NULL,
  `hours` int(11) DEFAULT NULL,
  `minutes` int(11) DEFAULT NULL,
  `seconds` int(11) DEFAULT NULL,
  `repeats` int(11) DEFAULT NULL,
  `job_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`),
  CONSTRAINT `job_interval_based_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_interval_based`
--

LOCK TABLES `job_interval_based` WRITE;
/*!40000 ALTER TABLE `job_interval_based` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_interval_based` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg_json_pointer`
--

DROP TABLE IF EXISTS `msg_json_pointer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg_json_pointer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `msg_json_pointer_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg_json_pointer`
--

LOCK TABLES `msg_json_pointer` WRITE;
/*!40000 ALTER TABLE `msg_json_pointer` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg_json_pointer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg_ns`
--

DROP TABLE IF EXISTS `msg_ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg_ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `msg_ns_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg_ns`
--

LOCK TABLES `msg_ns` WRITE;
/*!40000 ALTER TABLE `msg_ns` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg_ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg_xpath`
--

DROP TABLE IF EXISTS `msg_xpath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg_xpath` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(1500) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `msg_xpath_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg_xpath`
--

LOCK TABLES `msg_xpath` WRITE;
/*!40000 ALTER TABLE `msg_xpath` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg_xpath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notif`
--

DROP TABLE IF EXISTS `notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notif` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `notif_type` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `interval` int(11) NOT NULL,
  `name_pattern` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_pattern_neg` tinyint(1) DEFAULT NULL,
  `get_data` tinyint(1) DEFAULT NULL,
  `get_data_patt` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `get_data_patt_neg` tinyint(1) DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `service_id` (`service_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `notif_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notif_ibfk_2` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notif`
--

LOCK TABLES `notif` WRITE;
/*!40000 ALTER TABLE `notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notif_os_swift`
--

DROP TABLE IF EXISTS `notif_os_swift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notif_os_swift` (
  `id` int(11) NOT NULL,
  `containers` varchar(20000) COLLATE utf8_unicode_ci NOT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`def_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `notif_os_swift_ibfk_1` FOREIGN KEY (`id`) REFERENCES `notif` (`id`),
  CONSTRAINT `notif_os_swift_ibfk_2` FOREIGN KEY (`def_id`) REFERENCES `os_swift` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notif_os_swift`
--

LOCK TABLES `notif_os_swift` WRITE;
/*!40000 ALTER TABLE `notif_os_swift` DISABLE KEYS */;
/*!40000 ALTER TABLE `notif_os_swift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notif_sql`
--

DROP TABLE IF EXISTS `notif_sql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notif_sql` (
  `id` int(11) NOT NULL,
  `query` text COLLATE utf8_unicode_ci NOT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`def_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `notif_sql_ibfk_1` FOREIGN KEY (`id`) REFERENCES `notif` (`id`),
  CONSTRAINT `notif_sql_ibfk_2` FOREIGN KEY (`def_id`) REFERENCES `sql_pool` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notif_sql`
--

LOCK TABLES `notif_sql` WRITE;
/*!40000 ALTER TABLE `notif_sql` DISABLE KEYS */;
/*!40000 ALTER TABLE `notif_sql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `os_swift`
--

DROP TABLE IF EXISTS `os_swift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `os_swift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `pool_size` int(11) NOT NULL,
  `auth_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `auth_version` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `retries` int(11) NOT NULL,
  `is_snet` tinyint(1) NOT NULL,
  `starting_backoff` int(11) NOT NULL,
  `max_backoff` int(11) NOT NULL,
  `tenant_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `should_validate_cert` tinyint(1) NOT NULL,
  `cacert` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `should_retr_ratelimit` tinyint(1) NOT NULL,
  `needs_tls_compr` tinyint(1) NOT NULL,
  `custom_options` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `os_swift_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `os_swift`
--

LOCK TABLES `os_swift` WRITE;
/*!40000 ALTER TABLE `os_swift` DISABLE KEYS */;
/*!40000 ALTER TABLE `os_swift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `out_amqp`
--

DROP TABLE IF EXISTS `out_amqp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `out_amqp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `delivery_mode` smallint(6) NOT NULL,
  `priority` smallint(6) NOT NULL DEFAULT '5',
  `content_type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content_encoding` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiration` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`def_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `out_amqp_ibfk_1` FOREIGN KEY (`def_id`) REFERENCES `conn_def_amqp` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_amqp`
--

LOCK TABLES `out_amqp` WRITE;
/*!40000 ALTER TABLE `out_amqp` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_amqp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `out_ftp`
--

DROP TABLE IF EXISTS `out_ftp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `out_ftp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `acct` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timeout` int(11) DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '21',
  `dircache` tinyint(1) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `out_ftp_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_ftp`
--

LOCK TABLES `out_ftp` WRITE;
/*!40000 ALTER TABLE `out_ftp` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_ftp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `out_odoo`
--

DROP TABLE IF EXISTS `out_odoo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `out_odoo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL DEFAULT '8069',
  `user` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `database` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `protocol` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pool_size` int(11) NOT NULL DEFAULT '3',
  `password` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `out_odoo_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_odoo`
--

LOCK TABLES `out_odoo` WRITE;
/*!40000 ALTER TABLE `out_odoo` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_odoo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `out_wmq`
--

DROP TABLE IF EXISTS `out_wmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `out_wmq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `delivery_mode` smallint(6) NOT NULL,
  `priority` smallint(6) NOT NULL DEFAULT '5',
  `expiration` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`def_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `out_wmq_ibfk_1` FOREIGN KEY (`def_id`) REFERENCES `conn_def_wmq` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_wmq`
--

LOCK TABLES `out_wmq` WRITE;
/*!40000 ALTER TABLE `out_wmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_wmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `out_zmq`
--

DROP TABLE IF EXISTS `out_zmq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `out_zmq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `socket_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `out_zmq_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `out_zmq`
--

LOCK TABLES `out_zmq` WRITE;
/*!40000 ALTER TABLE `out_zmq` DISABLE KEYS */;
/*!40000 ALTER TABLE `out_zmq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pub_sub_consumer`
--

DROP TABLE IF EXISTS `pub_sub_consumer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pub_sub_consumer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `sub_key` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `max_depth` int(11) NOT NULL,
  `delivery_mode` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `callback_id` int(11) DEFAULT NULL,
  `callback_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `topic_id` int(11) NOT NULL,
  `sec_def_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sec_def_id` (`sec_def_id`,`topic_id`,`cluster_id`),
  KEY `callback_id` (`callback_id`),
  KEY `topic_id` (`topic_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `pub_sub_consumer_ibfk_1` FOREIGN KEY (`callback_id`) REFERENCES `http_soap` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pub_sub_consumer_ibfk_2` FOREIGN KEY (`topic_id`) REFERENCES `pub_sub_topic` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pub_sub_consumer_ibfk_3` FOREIGN KEY (`sec_def_id`) REFERENCES `sec_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pub_sub_consumer_ibfk_4` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pub_sub_consumer`
--

LOCK TABLES `pub_sub_consumer` WRITE;
/*!40000 ALTER TABLE `pub_sub_consumer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pub_sub_consumer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pub_sub_producer`
--

DROP TABLE IF EXISTS `pub_sub_producer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pub_sub_producer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `sec_def_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sec_def_id` (`sec_def_id`,`topic_id`,`cluster_id`),
  KEY `topic_id` (`topic_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `pub_sub_producer_ibfk_1` FOREIGN KEY (`topic_id`) REFERENCES `pub_sub_topic` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pub_sub_producer_ibfk_2` FOREIGN KEY (`sec_def_id`) REFERENCES `sec_base` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pub_sub_producer_ibfk_3` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pub_sub_producer`
--

LOCK TABLES `pub_sub_producer` WRITE;
/*!40000 ALTER TABLE `pub_sub_producer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pub_sub_producer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pub_sub_topic`
--

DROP TABLE IF EXISTS `pub_sub_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pub_sub_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `max_depth` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `pub_sub_topic_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pub_sub_topic`
--

LOCK TABLES `pub_sub_topic` WRITE;
/*!40000 ALTER TABLE `pub_sub_topic` DISABLE KEYS */;
/*!40000 ALTER TABLE `pub_sub_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `query_cassandra`
--

DROP TABLE IF EXISTS `query_cassandra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `query_cassandra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `value` blob NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `def_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `def_id` (`def_id`),
  CONSTRAINT `query_cassandra_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE,
  CONSTRAINT `query_cassandra_ibfk_2` FOREIGN KEY (`def_id`) REFERENCES `conn_def_cassandra` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `query_cassandra`
--

LOCK TABLES `query_cassandra` WRITE;
/*!40000 ALTER TABLE `query_cassandra` DISABLE KEYS */;
/*!40000 ALTER TABLE `query_cassandra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_client_role`
--

DROP TABLE IF EXISTS `rbac_client_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_client_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `client_def` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_def` (`client_def`,`role_id`,`cluster_id`),
  KEY `role_id` (`role_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `rbac_client_role_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `rbac_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_client_role_ibfk_2` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_client_role`
--

LOCK TABLES `rbac_client_role` WRITE;
/*!40000 ALTER TABLE `rbac_client_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_client_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_perm`
--

DROP TABLE IF EXISTS `rbac_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_perm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `rbac_perm_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_perm`
--

LOCK TABLES `rbac_perm` WRITE;
/*!40000 ALTER TABLE `rbac_perm` DISABLE KEYS */;
INSERT INTO `rbac_perm` VALUES (1,'Create',1),(4,'Delete',1),(2,'Read',1),(3,'Update',1);
/*!40000 ALTER TABLE `rbac_perm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_role`
--

DROP TABLE IF EXISTS `rbac_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `parent_id` (`parent_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `rbac_role_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `rbac_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_ibfk_2` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_role`
--

LOCK TABLES `rbac_role` WRITE;
/*!40000 ALTER TABLE `rbac_role` DISABLE KEYS */;
INSERT INTO `rbac_role` VALUES (1,'Root',NULL,1);
/*!40000 ALTER TABLE `rbac_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_role_perm`
--

DROP TABLE IF EXISTS `rbac_role_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_role_perm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `perm_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`perm_id`,`service_id`,`cluster_id`),
  KEY `perm_id` (`perm_id`),
  KEY `service_id` (`service_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `rbac_role_perm_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `rbac_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_perm_ibfk_2` FOREIGN KEY (`perm_id`) REFERENCES `rbac_perm` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_perm_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_perm_ibfk_4` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_role_perm`
--

LOCK TABLES `rbac_role_perm` WRITE;
/*!40000 ALTER TABLE `rbac_role_perm` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_role_perm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_es`
--

DROP TABLE IF EXISTS `search_es`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_es` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `hosts` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `timeout` int(11) NOT NULL,
  `body_as` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `search_es_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_es`
--

LOCK TABLES `search_es` WRITE;
/*!40000 ALTER TABLE `search_es` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_es` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_solr`
--

DROP TABLE IF EXISTS `search_solr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_solr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `timeout` int(11) NOT NULL,
  `ping_path` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `options` varchar(800) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pool_size` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `search_solr_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_solr`
--

LOCK TABLES `search_solr` WRITE;
/*!40000 ALTER TABLE `search_solr` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_solr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_apikey`
--

DROP TABLE IF EXISTS `sec_apikey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_apikey` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_apikey_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_apikey`
--

LOCK TABLES `sec_apikey` WRITE;
/*!40000 ALTER TABLE `sec_apikey` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_apikey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_aws`
--

DROP TABLE IF EXISTS `sec_aws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_aws` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_aws_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_aws`
--

LOCK TABLES `sec_aws` WRITE;
/*!40000 ALTER TABLE `sec_aws` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_aws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_base`
--

DROP TABLE IF EXISTS `sec_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `sec_type` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cluster_id` (`cluster_id`,`name`),
  UNIQUE KEY `cluster_id_2` (`cluster_id`,`username`,`sec_type`),
  CONSTRAINT `sec_base_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_base`
--

LOCK TABLES `sec_base` WRITE;
/*!40000 ALTER TABLE `sec_base` DISABLE KEYS */;
INSERT INTO `sec_base` VALUES (1,'admin.invoke','admin.invoke','f0e29fb0434c42bdbba9b4a3532bf14c',NULL,1,'basic_auth',1),(2,'pubapi','pubapi','3fc51110debd47aebffcbb99a68bf80f',NULL,1,'basic_auth',1),(3,'zato.ping.plain_http.basic_auth','zato.ping.plain_http.basic_auth','f777a0fae7ab483d9bd7487cd98ae899',NULL,1,'basic_auth',1),(4,'zato.ping.soap.basic_auth','zato.ping.soap.basic_auth','167b27c3bdb64b2b8fcec935fc7a6cdc',NULL,1,'basic_auth',1),(5,'zato.ping.soap.wss.clear_text','zato.ping.soap.wss.clear_text','9ec4a51d748b4b02babc3b503355d1ea','clear_text',1,'wss',1),(6,'zato.pubsub.default-consumer','zato.pubsub.default-consumer','16706d906461406aa91284ded94950a7',NULL,1,'basic_auth',1),(7,'zato.pubsub.default-producer','zato.pubsub.default-producer','224b84855f0e4398ada422a08b4f687f',NULL,1,'basic_auth',1);
/*!40000 ALTER TABLE `sec_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_basic_auth`
--

DROP TABLE IF EXISTS `sec_basic_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_basic_auth` (
  `id` int(11) NOT NULL,
  `realm` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_basic_auth_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_basic_auth`
--

LOCK TABLES `sec_basic_auth` WRITE;
/*!40000 ALTER TABLE `sec_basic_auth` DISABLE KEYS */;
INSERT INTO `sec_basic_auth` VALUES (1,'Zato admin invoke'),(2,'Zato public API'),(3,'Zato ping'),(4,'Zato ping'),(6,'Zato pub/sub'),(7,'Zato pub/sub');
/*!40000 ALTER TABLE `sec_basic_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_ntlm`
--

DROP TABLE IF EXISTS `sec_ntlm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_ntlm` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_ntlm_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_ntlm`
--

LOCK TABLES `sec_ntlm` WRITE;
/*!40000 ALTER TABLE `sec_ntlm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_ntlm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_oauth`
--

DROP TABLE IF EXISTS `sec_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_oauth` (
  `id` int(11) NOT NULL,
  `proto_version` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `sig_method` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `max_nonce_log` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_oauth_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_oauth`
--

LOCK TABLES `sec_oauth` WRITE;
/*!40000 ALTER TABLE `sec_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_openstack`
--

DROP TABLE IF EXISTS `sec_openstack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_openstack` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_openstack_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_openstack`
--

LOCK TABLES `sec_openstack` WRITE;
/*!40000 ALTER TABLE `sec_openstack` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_openstack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_tech_acc`
--

DROP TABLE IF EXISTS `sec_tech_acc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_tech_acc` (
  `id` int(11) NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_tech_acc_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_tech_acc`
--

LOCK TABLES `sec_tech_acc` WRITE;
/*!40000 ALTER TABLE `sec_tech_acc` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_tech_acc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_tls_ca_cert`
--

DROP TABLE IF EXISTS `sec_tls_ca_cert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_tls_ca_cert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` mediumblob NOT NULL,
  `info` mediumblob NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `sec_tls_ca_cert_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_tls_ca_cert`
--

LOCK TABLES `sec_tls_ca_cert` WRITE;
/*!40000 ALTER TABLE `sec_tls_ca_cert` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_tls_ca_cert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_tls_channel`
--

DROP TABLE IF EXISTS `sec_tls_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_tls_channel` (
  `id` int(11) NOT NULL,
  `value` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_tls_channel_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_tls_channel`
--

LOCK TABLES `sec_tls_channel` WRITE;
/*!40000 ALTER TABLE `sec_tls_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_tls_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_tls_key_cert`
--

DROP TABLE IF EXISTS `sec_tls_key_cert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_tls_key_cert` (
  `id` int(11) NOT NULL,
  `info` mediumblob NOT NULL,
  `value` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_tls_key_cert_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_tls_key_cert`
--

LOCK TABLES `sec_tls_key_cert` WRITE;
/*!40000 ALTER TABLE `sec_tls_key_cert` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_tls_key_cert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_wss_def`
--

DROP TABLE IF EXISTS `sec_wss_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_wss_def` (
  `id` int(11) NOT NULL,
  `reject_empty_nonce_creat` tinyint(1) NOT NULL,
  `reject_stale_tokens` tinyint(1) DEFAULT NULL,
  `reject_expiry_limit` int(11) NOT NULL,
  `nonce_freshness_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_wss_def_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_wss_def`
--

LOCK TABLES `sec_wss_def` WRITE;
/*!40000 ALTER TABLE `sec_wss_def` DISABLE KEYS */;
INSERT INTO `sec_wss_def` VALUES (5,0,1,3600,3600);
/*!40000 ALTER TABLE `sec_wss_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sec_xpath`
--

DROP TABLE IF EXISTS `sec_xpath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_xpath` (
  `id` int(11) NOT NULL,
  `username_expr` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `password_expr` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `sec_xpath_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sec_base` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_xpath`
--

LOCK TABLES `sec_xpath` WRITE;
/*!40000 ALTER TABLE `sec_xpath` DISABLE KEYS */;
/*!40000 ALTER TABLE `sec_xpath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_host` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_port` int(11) DEFAULT NULL,
  `last_join_status` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_join_mod_date` datetime DEFAULT NULL,
  `last_join_mod_by` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `up_status` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `up_mod_date` datetime DEFAULT NULL,
  `token` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `server_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` VALUES (1,'server1',NULL,NULL,NULL,'accepted','2018-01-25 02:59:14','dmw@zato',NULL,NULL,'962fb58de48c4f37aab6079d99daaba8',1);
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `impl_name` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `is_internal` tinyint(1) NOT NULL,
  `wsdl` mediumblob,
  `wsdl_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slow_threshold` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`cluster_id`),
  KEY `cluster_id` (`cluster_id`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'zato.security.wss.create',1,'zato.server.service.internal.security.wss.Create',1,NULL,NULL,99999,1),(2,'zato.security.apikey.edit',1,'zato.server.service.internal.security.apikey.Edit',1,NULL,NULL,99999,1),(3,'zato.cloud.openstack.swift.create',1,'zato.server.service.internal.cloud.openstack.swift.Create',1,NULL,NULL,99999,1),(4,'zato.service.configure-request-response',1,'zato.server.service.internal.service.ConfigureRequestResponse',1,NULL,NULL,99999,1),(5,'zato.email.imap.edit',1,'zato.server.service.internal.email.imap.Edit',1,NULL,NULL,99999,1),(6,'zato.security.tech-account.get-list',1,'zato.server.service.internal.security.tech_account.GetList',1,NULL,NULL,99999,1),(7,'zato.security.tls.ca_cert.change-password',1,'zato.server.service.internal.security.tls.ca_cert.ChangePassword',1,NULL,NULL,99999,1),(8,'zato.pubsub.producers.delete',1,'zato.server.service.internal.pubsub.producers.Delete',1,NULL,NULL,99999,1),(9,'zato.server.message.json_pointer.get-list',1,'zato.server.service.internal.message.json_pointer.GetList',1,NULL,NULL,99999,1),(10,'zato.helpers.input-logger',1,'zato.server.service.internal.helpers.InputLogger',1,NULL,NULL,99999,1),(11,'zato.service.upload-package',1,'zato.server.service.internal.service.UploadPackage',1,NULL,NULL,99999,1),(12,'zato.pubsub.producers.get-list',1,'zato.server.service.internal.pubsub.producers.GetList',1,NULL,NULL,99999,1),(13,'zato.kvdb.data-dict.dictionary.get-list',1,'zato.server.service.internal.kvdb.data_dict.dictionary.GetList',1,NULL,NULL,99999,1),(14,'zato.notif.cloud.openstack.swift.edit',1,'zato.server.service.internal.notif.cloud.openstack.swift.Edit',1,NULL,NULL,99999,1),(15,'zato.channel.jms-wmq.edit',1,'zato.server.service.internal.channel.jms_wmq.Edit',1,NULL,NULL,99999,1),(16,'zato.security.tls.ca_cert.delete',1,'zato.server.service.internal.security.tls.ca_cert.Delete',1,NULL,NULL,99999,1),(17,'zato.security.oauth.get-list',1,'zato.server.service.internal.security.oauth.GetList',1,NULL,NULL,99999,1),(18,'zato.http-soap.ping',1,'zato.server.service.internal.http_soap.Ping',1,NULL,NULL,99999,1),(19,'zato.kvdb.data-dict.translation.delete',1,'zato.server.service.internal.kvdb.data_dict.translation.Delete',1,NULL,NULL,99999,1),(20,'zato.outgoing.ftp.create',1,'zato.server.service.internal.outgoing.ftp.Create',1,NULL,NULL,99999,1),(21,'zato.outgoing.zmq.get-list',1,'zato.server.service.internal.outgoing.zmq.GetList',1,NULL,NULL,99999,1),(22,'zato.security.openstack.create',1,'zato.server.service.internal.security.openstack.Create',1,NULL,NULL,99999,1),(23,'zato.helpers.sio-input-logger',1,'zato.server.service.internal.helpers.SIOInputLogger',1,NULL,NULL,99999,1),(24,'zato.hot_deploy.create',1,'zato.server.service.internal.hot_deploy.Create',1,NULL,NULL,99999,1),(25,'zato.stats.delete',1,'zato.server.service.internal.stats.Delete',1,NULL,NULL,99999,1),(26,'zato.pubsub.topics.create',1,'zato.server.service.internal.pubsub.topics.Create',1,NULL,NULL,99999,1),(27,'zato.scheduler.job.create',1,'zato.server.service.internal.scheduler.Create',1,NULL,NULL,99999,1),(28,'zato.service.get-deployment-info-list',1,'zato.server.service.internal.service.GetDeploymentInfoList',1,NULL,NULL,99999,1),(29,'zato.scheduler.job.delete',1,'zato.server.service.internal.scheduler.Delete',1,NULL,NULL,99999,1),(30,'zato.definition.amqp.get-list',1,'zato.server.service.internal.definition.amqp.GetList',1,NULL,NULL,99999,1),(31,'zato.security.openstack.delete',1,'zato.server.service.internal.security.openstack.Delete',1,NULL,NULL,99999,1),(32,'zato.security.tls.ca_cert.edit',1,'zato.server.service.internal.security.tls.ca_cert.Edit',1,NULL,NULL,99999,1),(33,'zato.pubsub.producers.create',1,'zato.server.service.internal.pubsub.producers.Create',1,NULL,NULL,99999,1),(34,'zato.pubsub.invoke-callbacks',1,'zato.server.service.internal.pubsub.InvokeCallbacks',1,NULL,NULL,99999,1),(35,'zato.pubsub.consumers.create',1,'zato.server.service.internal.pubsub.consumers.Create',1,NULL,NULL,99999,1),(36,'zato.helpers.echo',1,'zato.server.service.internal.helpers.Echo',1,NULL,NULL,99999,1),(37,'zato.email.imap.delete',1,'zato.server.service.internal.email.imap.Delete',1,NULL,NULL,99999,1),(38,'zato.channel.amqp.create',1,'zato.server.service.internal.channel.amqp.Create',1,NULL,NULL,99999,1),(39,'zato.security.apikey.create',1,'zato.server.service.internal.security.apikey.Create',1,NULL,NULL,99999,1),(40,'zato.security.rbac.role.get-list',1,'zato.server.service.internal.security.rbac.role.get-list',1,NULL,NULL,99999,1),(41,'zato.security.tech-account.edit',1,'zato.server.service.internal.security.tech_account.Edit',1,NULL,NULL,99999,1),(42,'zato.cloud.aws.s3.edit',1,'zato.server.service.internal.cloud.aws.s3.Edit',1,NULL,NULL,99999,1),(43,'zato.http-soap.create',1,'zato.server.service.internal.http_soap.Create',1,NULL,NULL,99999,1),(44,'zato.email.smtp.create',1,'zato.server.service.internal.email.smtp.Create',1,NULL,NULL,99999,1),(45,'zato.security.basic-auth.change-password',1,'zato.server.service.internal.security.basic_auth.ChangePassword',1,NULL,NULL,99999,1),(46,'zato.kvdb.data-dict.dictionary.edit',1,'zato.server.service.internal.kvdb.data_dict.dictionary.Edit',1,NULL,NULL,99999,1),(47,'zato.search.es.get-list',1,'zato.server.service.internal.search.es.GetList',1,NULL,NULL,99999,1),(48,'zato.service.set-wsdl',1,'zato.server.service.internal.service.SetWSDL',1,NULL,NULL,99999,1),(49,'zato.security.aws.edit',1,'zato.server.service.internal.security.aws.Edit',1,NULL,NULL,99999,1),(50,'zato.pubsub.producers.edit',1,'zato.server.service.internal.pubsub.producers.Edit',1,NULL,NULL,99999,1),(51,'zato.service.get-wsdl',1,'zato.server.service.internal.service.GetWSDL',1,NULL,NULL,99999,1),(52,'zato.pubsub.move-to-target-queues',1,'zato.server.service.internal.pubsub.MoveToTargetQueues',1,NULL,NULL,99999,1),(53,'zato.search.solr.create',1,'zato.server.service.internal.search.solr.Create',1,NULL,NULL,99999,1),(54,'zato.outgoing.jms-wmq.get-list',1,'zato.server.service.internal.outgoing.jms_wmq.GetList',1,NULL,NULL,99999,1),(55,'zato.stats.summary.get-summary-by-month',1,'zato.server.service.internal.stats.summary.GetSummaryByMonth',1,NULL,NULL,99999,1),(56,'zato.security.rbac.role.delete',1,'zato.server.service.internal.security.rbac.role.Delete',1,NULL,NULL,99999,1),(57,'zato.security.oauth.change-password',1,'zato.server.service.internal.security.oauth.ChangePassword',1,NULL,NULL,99999,1),(58,'zato.stats.summary.get-summary-by-year',1,'zato.server.service.internal.stats.summary.GetSummaryByYear',1,NULL,NULL,99999,1),(59,'zato.outgoing.sql.create',1,'zato.server.service.internal.outgoing.sql.Create',1,NULL,NULL,99999,1),(60,'zato.pubsub.producers.get-info',1,'zato.server.service.internal.pubsub.producers.GetInfo',1,NULL,NULL,99999,1),(61,'zato.search.es.delete',1,'zato.server.service.internal.search.es.Delete',1,NULL,NULL,99999,1),(62,'zato.pubsub.message.create.delete',1,'zato.server.service.internal.pubsub.message.Delete',1,NULL,NULL,99999,1),(63,'zato.security.tls.ca_cert.create',1,'zato.server.service.internal.security.tls.ca_cert.Create',1,NULL,NULL,99999,1),(64,'zato.server.edit',1,'zato.server.service.internal.server.Edit',1,NULL,NULL,99999,1),(65,'zato.definition.jms-wmq.delete',1,'zato.server.service.internal.definition.jms_wmq.Delete',1,NULL,NULL,99999,1),(66,'zato.security.tls.key_cert.create',1,'zato.server.service.internal.security.tls.key_cert.Create',1,NULL,NULL,99999,1),(67,'zato.security.rbac.client-role.delete',1,'zato.server.service.internal.security.rbac.client_role.Delete',1,NULL,NULL,99999,1),(68,'zato.server.delete',1,'zato.server.service.internal.server.Delete',1,NULL,NULL,99999,1),(69,'zato.definition.amqp.edit',1,'zato.server.service.internal.definition.amqp.Edit',1,NULL,NULL,99999,1),(70,'zato.outgoing.ftp.change-password',1,'zato.server.service.internal.outgoing.ftp.ChangePassword',1,NULL,NULL,99999,1),(71,'zato.security.xpath.get-list',1,'zato.server.service.internal.security.xpath.GetList',1,NULL,NULL,99999,1),(72,'zato.outgoing.sql.edit',1,'zato.server.service.internal.outgoing.sql.Edit',1,NULL,NULL,99999,1),(73,'zato.server.message.json_pointer.edit',1,'zato.server.service.internal.message.json_pointer.Edit',1,NULL,NULL,99999,1),(74,'zato.pubsub.consumers.get-info',1,'zato.server.service.internal.pubsub.consumers.GetInfo',1,NULL,NULL,99999,1),(75,'zato.security.rbac.client-role.get-list',1,'zato.server.service.internal.security.rbac.client_role.get-list',1,NULL,NULL,99999,1),(76,'zato.outgoing.sql.get-list',1,'zato.server.service.internal.outgoing.sql.GetList',1,NULL,NULL,99999,1),(77,'zato.definition.cassandra.delete',1,'zato.server.service.internal.definition.cassandra.Delete',1,NULL,NULL,99999,1),(78,'zato.service.get-by-name',1,'zato.server.service.internal.service.GetByName',1,NULL,NULL,99999,1),(79,'zato.security.rbac.permission.delete',1,'zato.server.service.internal.security.rbac.permission.Delete',1,NULL,NULL,99999,1),(80,'zato.info.get-info',1,'zato.server.service.internal.info.GetInfo',1,NULL,NULL,99999,1),(81,'zato.outgoing.odoo.create',1,'zato.server.service.internal.outgoing.odoo.Create',1,NULL,NULL,99999,1),(82,'zato.outgoing.zmq.delete',1,'zato.server.service.internal.outgoing.zmq.Delete',1,NULL,NULL,99999,1),(83,'zato.security.rbac.role.create',1,'zato.server.service.internal.security.rbac.role.Create',1,NULL,NULL,99999,1),(84,'zato.outgoing.ftp.get-list',1,'zato.server.service.internal.outgoing.ftp.GetList',1,NULL,NULL,99999,1),(85,'zato.definition.amqp.change-password',1,'zato.server.service.internal.definition.amqp.ChangePassword',1,NULL,NULL,99999,1),(86,'zato.email.imap.create',1,'zato.server.service.internal.email.imap.Create',1,NULL,NULL,99999,1),(87,'zato.definition.amqp.get-by-id',1,'zato.server.service.internal.definition.amqp.GetByID',1,NULL,NULL,99999,1),(88,'zato.outgoing.odoo.edit',1,'zato.server.service.internal.outgoing.odoo.Edit',1,NULL,NULL,99999,1),(89,'zato.server.message.namespace.delete',1,'zato.server.service.internal.message.namespace.Delete',1,NULL,NULL,99999,1),(90,'zato.scheduler.job.execute',1,'zato.server.service.internal.scheduler.Execute',1,NULL,NULL,99999,1),(91,'zato.email.imap.get-list',1,'zato.server.service.internal.email.imap.GetList',1,NULL,NULL,99999,1),(92,'zato.cloud.aws.s3.get-list',1,'zato.server.service.internal.cloud.aws.s3.GetList',1,NULL,NULL,99999,1),(93,'zato.kvdb.data-dict.translation.get-list',1,'zato.server.service.internal.kvdb.data_dict.translation.GetList',1,NULL,NULL,99999,1),(94,'zato.security.openstack.get-list',1,'zato.server.service.internal.security.openstack.GetList',1,NULL,NULL,99999,1),(95,'zato.security.tech-account.get-by-id',1,'zato.server.service.internal.security.tech_account.GetByID',1,NULL,NULL,99999,1),(96,'zato.cloud.aws.s3.delete',1,'zato.server.service.internal.cloud.aws.s3.Delete',1,NULL,NULL,99999,1),(97,'zato.security.openstack.edit',1,'zato.server.service.zato_servicesinternal.security.openstack.Edit',1,NULL,NULL,99999,1),(98,'zato.definition.cassandra.create',1,'zato.server.service.internal.definition.cassandra.Create',1,NULL,NULL,99999,1),(99,'zato.security.wss.change-password',1,'zato.server.service.internal.security.wss.ChangePassword',1,NULL,NULL,99999,1),(100,'zato.definition.cassandra.edit',1,'zato.server.service.internal.definition.cassandra.Edit',1,NULL,NULL,99999,1),(101,'zato.outgoing.amqp.edit',1,'zato.server.service.internal.outgoing.amqp.Edit',1,NULL,NULL,99999,1),(102,'zato.service.slow-response.get',1,'zato.server.service.internal.service.GetSlowResponse',1,NULL,NULL,99999,1),(103,'zato.query.cassandra.delete',1,'zato.server.service.internal.query.cassandra.Delete',1,NULL,NULL,99999,1),(104,'zato.pubsub.topics.get-list',1,'zato.server.service.internal.pubsub.topics.GetList',1,NULL,NULL,99999,1),(105,'zato.email.smtp.change-password',1,'zato.server.service.internal.email.smtp.ChangePassword',1,NULL,NULL,99999,1),(106,'zato.http-soap.delete',1,'zato.server.service.internal.http_soap.Delete',1,NULL,NULL,99999,1),(107,'zato.kvdb.data-dict.translation.create',1,'zato.server.service.internal.kvdb.data_dict.translation.Create',1,NULL,NULL,99999,1),(108,'zato.pubsub.message.create.get',1,'zato.server.service.internal.pubsub.message.Get',1,NULL,NULL,99999,1),(109,'zato.security.rbac.permission.edit',1,'zato.server.service.internal.security.rbac.permission.Edit',1,NULL,NULL,99999,1),(110,'zato.security.aws.change-password',1,'zato.server.service.internal.security.aws.ChangePassword',1,NULL,NULL,99999,1),(111,'zato.security.oauth.delete',1,'zato.server.service.internal.security.oauth.Delete',1,NULL,NULL,99999,1),(112,'zato.outgoing.amqp.create',1,'zato.server.service.internal.outgoing.amqp.Create',1,NULL,NULL,99999,1),(113,'zato.outgoing.sql.change-password',1,'zato.server.service.internal.outgoing.sql.ChangePassword',1,NULL,NULL,99999,1),(114,'zato.scheduler.job.get-list',1,'zato.server.service.internal.scheduler.GetList',1,NULL,NULL,99999,1),(115,'zato.service.get-channel-list',1,'zato.server.service.interna.sol.service.GetChannelList',1,NULL,NULL,99999,1),(116,'zato.security.basic-auth.create',1,'zato.server.service.internal.security.basic_auth.Create',1,NULL,NULL,99999,1),(117,'zato.security.xpath.create',1,'zato.server.service.internal.security.xpath.Create',1,NULL,NULL,99999,1),(118,'zato.kvdb.remote-command.execute',1,'zato.server.service.internal.kvdb.ExecuteCommand',1,NULL,NULL,99999,1),(119,'zato.outgoing.odoo.get-list',1,'zato.server.service.internal.outgoing.odoo.GetList',1,NULL,NULL,99999,1),(120,'zato.security.aws.create',1,'zato.server.service.internal.security.aws.Create',1,NULL,NULL,99999,1),(121,'zato.kvdb.data-dict.impexp.import',1,'zato.server.service.internal.kvdb.data_dict.impexp.Import',1,NULL,NULL,99999,1),(122,'zato.outgoing.zmq.create',1,'zato.server.service.internal.outgoing.zmq.Create',1,NULL,NULL,99999,1),(123,'zato.security.rbac.permission.create',1,'zato.server.service.internal.security.rbac.permission.Create',1,NULL,NULL,99999,1),(124,'zato.definition.jms-wmq.get-list',1,'zato.server.service.internal.definition.jms_wmq.GetList',1,NULL,NULL,99999,1),(125,'zato.kvdb.data-dict.translation.get-last-id',1,'zato.server.service.internal.kvdb.data_dict.translation.GetLastID',1,NULL,NULL,99999,1),(126,'zato.security.rbac.permission.get-list',1,'zato.server.service.internal.security.rbac.permission.get-list',1,NULL,NULL,99999,1),(127,'zato.cloud.aws.s3.create',1,'zato.server.service.internal.cloud.aws.s3.Create',1,NULL,NULL,99999,1),(128,'zato.definition.jms-wmq.edit',1,'zato.server.service.internal.definition.jms_wmq.Edit',1,NULL,NULL,99999,1),(129,'zato.stats.summary.get-summary-by-day',1,'zato.server.service.internal.stats.summary.GetSummaryByDay',1,NULL,NULL,99999,1),(130,'zato.security.rbac.role-permission.create',1,'zato.server.service.internal.security.rbac.role_permission.Create',1,NULL,NULL,99999,1),(131,'zato.scheduler.job.get-by-name',1,'zato.server.service.internal.scheduler.GetByName',1,NULL,NULL,99999,1),(132,'zato.stats.summary.get-summary-by-range',1,'zato.server.service.internal.stats.summary.GetSummaryByRange',1,NULL,NULL,99999,1),(133,'zato.pubsub.delete-expired',1,'zato.server.service.internal.pubsub.DeleteExpired',1,NULL,NULL,99999,1),(134,'zato.security.wss.edit',1,'zato.server.service.internal.security.wss.Edit',1,NULL,NULL,99999,1),(135,'zato.channel.amqp.get-list',1,'zato.server.service.internal.channel.amqp.GetList',1,NULL,NULL,99999,1),(136,'zato.server.message.namespace.get-list',1,'zato.server.service.internal.message.namespace.GetList',1,NULL,NULL,99999,1),(137,'zato.channel.zmq.create',1,'zato.server.service.internal.channel.zmq.Create',1,NULL,NULL,99999,1),(138,'zato.security.xpath.edit',1,'zato.server.service.internal.security.xpath.Edit',1,NULL,NULL,99999,1),(139,'zato.server.message.xpath.delete',1,'zato.server.service.internal.message.xpath.Delete',1,NULL,NULL,99999,1),(140,'zato.definition.cassandra.get-by-id',1,'zato.server.service.internal.definition.cassandra.GetByID',1,NULL,NULL,99999,1),(141,'zato.kvdb.data-dict.dictionary.get-system-list',1,'zato.server.service.internal.kvdb.data_dict.dictionary.GetSystemList',1,NULL,NULL,99999,1),(142,'zato.pubsub.message.create.get-list',1,'zato.server.service.internal.pubsub.message.GetList',1,NULL,NULL,99999,1),(143,'zato.pubsub.consumers.get-list',1,'zato.server.service.internal.pubsub.consumers.GetList',1,NULL,NULL,99999,1),(144,'zato.kvdb.data-dict.dictionary.get-value-list',1,'zato.server.service.internal.kvdb.data_dict.dictionary.GetValueList',1,NULL,NULL,99999,1),(145,'zato.outgoing.sql.ping',1,'zato.server.service.internal.outgoing.sql.Ping',1,NULL,NULL,99999,1),(146,'zato.security.get-list',1,'zato.server.service.internal.security.GetList',1,NULL,NULL,99999,1),(147,'zato.outgoing.sql.delete',1,'zato.server.service.internal.outgoing.sql.Delete',1,NULL,NULL,99999,1),(148,'zato.cloud.openstack.swift.delete',1,'zato.server.service.internal.cloud.openstack.swift.Delete',1,NULL,NULL,99999,1),(149,'zato.security.apikey.change-password',1,'zato.server.service.internal.security.apikey.ChangePassword',1,NULL,NULL,99999,1),(150,'zato.search.solr.delete',1,'zato.server.service.internal.search.solr.Delete',1,NULL,NULL,99999,1),(151,'zato.kvdb.data-dict.dictionary.delete',1,'zato.server.service.internal.kvdb.data_dict.dictionary.Delete',1,NULL,NULL,99999,1),(152,'zato.pubsub.consumers.delete',1,'zato.server.service.internal.pubsub.consumers.Delete',1,NULL,NULL,99999,1),(153,'zato.http-soap.edit',1,'zato.server.service.internal.http_soap.Edit',1,NULL,NULL,99999,1),(154,'zato.definition.jms-wmq.get-by-id',1,'zato.server.service.internal.definition.jms_wmq.GetByID',1,NULL,NULL,99999,1),(155,'zato.kvdb.data-dict.translation.edit',1,'zato.server.service.internal.kvdb.data_dict.translation.Edit',1,NULL,NULL,99999,1),(156,'zato.security.basic-auth.get-list',1,'zato.server.service.internal.security.basic_auth.GetList',1,NULL,NULL,99999,1),(157,'zato.definition.amqp.delete',1,'zato.server.service.internal.definition.amqp.Delete',1,NULL,NULL,99999,1),(158,'zato.security.rbac.client-role.create',1,'zato.server.service.internal.security.rbac.client_role.Create',1,NULL,NULL,99999,1),(159,'zato.service.get-source-info',1,'zato.server.service.internal.service.GetSourceInfo',1,NULL,NULL,99999,1),(160,'zato.security.rbac.role-permission.get-list',1,'zato.server.service.internal.security.rbac.role_permission.get-list',1,NULL,NULL,99999,1),(161,'zato.security.tech-account.create',1,'zato.server.service.internal.security.tech_account.Create',1,NULL,NULL,99999,1),(162,'zato.server.message.namespace.edit',1,'zato.server.service.internal.message.namespace.Edit',1,NULL,NULL,99999,1),(163,'zato.search.solr.get-list',1,'zato.server.service.internal.search.solr.GetList',1,NULL,NULL,99999,1),(164,'zato.notif.cloud.sql.delete',1,'zato.server.service.internal.notif.cloud.sql.Delete',1,NULL,NULL,99999,1),(165,'zato.security.rbac.role-permission.delete',1,'zato.server.service.internal.security.rbac.role_permission.Delete',1,NULL,NULL,99999,1),(166,'zato.query.cassandra.get-list',1,'zato.server.service.internal.query.cassandra.GetList',1,NULL,NULL,99999,1),(167,'zato.outgoing.amqp.get-list',1,'zato.server.service.internal.outgoing.amqp.GetList',1,NULL,NULL,99999,1),(168,'zato.security.tls.ca_cert.get-list',1,'zato.server.service.internal.security.tls.ca_cert.GetList',1,NULL,NULL,99999,1),(169,'zato.security.oauth.edit',1,'zato.server.service.internal.security.oauth.Edit',1,NULL,NULL,99999,1),(170,'zato.server.get-by-id',1,'zato.server.service.internal.server.GetByID',1,NULL,NULL,99999,1),(171,'zato.security.tech-account.delete',1,'zato.server.service.internal.security.tech_account.Delete',1,NULL,NULL,99999,1),(172,'zato.server.message.namespace.create',1,'zato.server.service.internal.message.namespace.Create',1,NULL,NULL,99999,1),(173,'zato.definition.amqp.create',1,'zato.server.service.internal.definition.amqp.Create',1,NULL,NULL,99999,1),(174,'zato.server.message.json_pointer.delete',1,'zato.server.service.internal.message.json_pointer.Delete',1,NULL,NULL,99999,1),(175,'zato.channel.jms-wmq.delete',1,'zato.server.service.internal.channel.jms_wmq.Delete',1,NULL,NULL,99999,1),(176,'zato.pubsub.topics.edit',1,'zato.server.service.internal.pubsub.topics.Edit',1,NULL,NULL,99999,1),(177,'zato.channel.amqp.delete',1,'zato.server.service.internal.channel.amqp.Delete',1,NULL,NULL,99999,1),(178,'zato.outgoing.zmq.edit',1,'zato.server.service.internal.outgoing.zmq.Edit',1,NULL,NULL,99999,1),(179,'zato.stats.summary.get-summary-by-week',1,'zato.server.service.internal.stats.summary.GetSummaryByWeek',1,NULL,NULL,99999,1),(180,'zato.security.xpath.delete',1,'zato.server.service.internal.security.xpath.Delete',1,NULL,NULL,99999,1),(181,'zato.pubsub.topics.get-info',1,'zato.server.service.internal.pubsub.topics.GetInfo',1,NULL,NULL,99999,1),(182,'zato.channel.jms-wmq.get-list',1,'zato.server.service.internal.channel.jms_wmq.GetList',1,NULL,NULL,99999,1),(183,'zato.outgoing.jms-wmq.edit',1,'zato.server.service.internal.outgoing.jms_wmq.Edit',1,NULL,NULL,99999,1),(184,'zato.outgoing.ftp.delete',1,'zato.server.service.internal.outgoing.ftp.Delete',1,NULL,NULL,99999,1),(185,'zato.security.basic-auth.delete',1,'zato.server.service.internal.security.basic_auth.Delete',1,NULL,NULL,99999,1),(186,'zato.http-soap.get-list',1,'zato.server.service.internal.http_soap.GetList',1,NULL,NULL,99999,1),(187,'zato.search.es.create',1,'zato.server.service.internal.search.es.Create',1,NULL,NULL,99999,1),(188,'zato.service.delete',1,'zato.server.service.internal.service.Delete',1,NULL,NULL,99999,1),(189,'zato.security.aws.delete',1,'zato.server.service.internal.security.aws.Delete',1,NULL,NULL,99999,1),(190,'zato.outgoing.jms-wmq.delete',1,'zato.server.service.internal.outgoing.jms_wmq.Delete',1,NULL,NULL,99999,1),(191,'zato.service.edit',1,'zato.server.service.internal.service.Edit',1,NULL,NULL,99999,1),(192,'zato.server.message.xpath.create',1,'zato.server.service.internal.message.xpath.Create',1,NULL,NULL,99999,1),(193,'zato.security.apikey.delete',1,'zato.server.service.internal.security.apikey.Delete',1,NULL,NULL,99999,1),(194,'zato.outgoing.odoo.change-password',1,'zato.server.service.internal.outgoing.odoo.ChangePassword',1,NULL,NULL,99999,1),(195,'zato.channel.zmq.edit',1,'zato.server.service.internal.channel.zmq.Edit',1,NULL,NULL,99999,1),(196,'zato.channel.zmq.get-list',1,'zato.server.service.internal.channel.zmq.GetList',1,NULL,NULL,99999,1),(197,'zato.server.message.xpath.edit',1,'zato.server.service.internal.message.xpath.Edit',1,NULL,NULL,99999,1),(198,'zato.search.solr.edit',1,'zato.server.service.internal.search.solr.Edit',1,NULL,NULL,99999,1),(199,'zato.security.tls.key_cert.edit',1,'zato.server.service.internal.security.tls.key_cert.Edit',1,NULL,NULL,99999,1),(200,'zato.pubsub.consumers.edit',1,'zato.server.service.internal.pubsub.consumers.Edit',1,NULL,NULL,99999,1),(201,'zato.service.get-list',1,'zato.server.service.internal.service.GetList',1,NULL,NULL,99999,1),(202,'zato.info.get-server-info',1,'zato.server.service.internal.info.GetServerInfo',1,NULL,NULL,99999,1),(203,'zato.cloud.openstack.swift.edit',1,'zato.server.service.internal.cloud.openstack.swift.Edit',1,NULL,NULL,99999,1),(204,'zato.channel.zmq.delete',1,'zato.server.service.internal.channel.zmq.Delete',1,NULL,NULL,99999,1),(205,'zato.email.imap.change-password',1,'zato.server.service.internal.email.imap.ChangePassword',1,NULL,NULL,99999,1),(206,'zato.outgoing.jms-wmq.create',1,'zato.server.service.internal.outgoing.jms_wmq.Create',1,NULL,NULL,99999,1),(207,'zato.security.wss.delete',1,'zato.server.service.internal.security.wss.Delete',1,NULL,NULL,99999,1),(208,'zato.stats.trends.get-trends',1,'zato.server.service.internal.stats.trends.GetTrends',1,NULL,NULL,99999,1),(209,'zato.pubsub.rest-handler',1,'zato.server.service.internal.pubsub.RESTHandler',1,NULL,NULL,99999,1),(210,'zato.service.has-wsdl',1,'zato.server.service.internal.service.HasWSDL',1,NULL,NULL,99999,1),(211,'zato.scheduler.job.edit',1,'zato.server.service.internal.scheduler.Edit',1,NULL,NULL,99999,1),(212,'zato.email.smtp.edit',1,'zato.server.service.internal.email.smtp.Edit',1,NULL,NULL,99999,1),(213,'zato.kvdb.data-dict.dictionary.get-key-list',1,'zato.server.service.internal.kvdb.data_dict.dictionary.GetKeyList',1,NULL,NULL,99999,1),(214,'zato.email.smtp.delete',1,'zato.server.service.internal.email.smtp.Delete',1,NULL,NULL,99999,1),(215,'zato.cloud.openstack.swift.get-list',1,'zato.server.service.internal.cloud.openstack.swift.GetList',1,NULL,NULL,99999,1),(216,'zato.outgoing.ftp.edit',1,'zato.server.service.internal.outgoing.ftp.Edit',1,NULL,NULL,99999,1),(217,'zato.kvdb.data-dict.dictionary.create',1,'zato.server.service.internal.kvdb.data_dict.dictionary.Create',1,NULL,NULL,99999,1),(218,'zato.security.basic-auth.edit',1,'zato.server.service.internal.security.basic_auth.Edit',1,NULL,NULL,99999,1),(219,'zato.definition.jms-wmq.create',1,'zato.server.service.internal.definition.jms_wmq.Create',1,NULL,NULL,99999,1),(220,'zato.security.tech-account.change-password',1,'zato.server.service.internal.security.tech_account.ChangePassword',1,NULL,NULL,99999,1),(221,'zato.notif.cloud.openstack.swift.create',1,'zato.server.service.internal.notif.cloud.openstack.swift.Create',1,NULL,NULL,99999,1),(222,'zato.email.imap.ping',1,'zato.server.service.internal.email.imap.Ping',1,NULL,NULL,99999,1),(223,'zato.security.aws.get-list',1,'zato.server.service.internal.security.aws.GetList',1,NULL,NULL,99999,1),(224,'zato.security.apikey.get-list',1,'zato.server.service.internal.security.apikey.GetList',1,NULL,NULL,99999,1),(225,'zato.server.message.json_pointer.create',1,'zato.server.service.internal.message.json_pointer.Create',1,NULL,NULL,99999,1),(226,'zato.security.tls.key_cert.get-list',1,'zato.server.service.internal.security.tls.key_cert.GetList',1,NULL,NULL,99999,1),(227,'zato.stats.get-by-service',1,'zato.server.service.internal.stats.GetByService',1,NULL,NULL,99999,1),(228,'zato.query.cassandra.edit',1,'zato.server.service.internal.query.cassandra.Edit',1,NULL,NULL,99999,1),(229,'zato.notif.cloud.sql.get-list',1,'zato.server.service.internal.notif.cloud.sql.GetList',1,NULL,NULL,99999,1),(230,'zato.notif.cloud.sql.create',1,'zato.server.service.internal.notif.cloud.sql.Create',1,NULL,NULL,99999,1),(231,'zato.channel.jms-wmq.create',1,'zato.server.service.internal.channel.jms_wmq.Create',1,NULL,NULL,99999,1),(232,'zato.outgoing.amqp.delete',1,'zato.server.service.internal.outgoing.amqp.Delete',1,NULL,NULL,99999,1),(233,'zato.notif.cloud.sql.edit',1,'zato.server.service.internal.notif.cloud.sql.Edit',1,NULL,NULL,99999,1),(234,'zato.definition.cassandra.get-list',1,'zato.server.service.internal.definition.cassandra.GetList',1,NULL,NULL,99999,1),(235,'zato.security.tls.key_cert.delete',1,'zato.server.service.internal.security.tls.key_cert.Delete',1,NULL,NULL,99999,1),(236,'zato.security.wss.get-list',1,'zato.server.service.internal.security.wss.GetList',1,NULL,NULL,99999,1),(237,'zato.security.xpath.change-password',1,'zato.server.service.internal.security.xpath.ChangePassword',1,NULL,NULL,99999,1),(238,'zato.pubsub.topics.publish',1,'zato.server.service.internal.pubsub.topics.Publish',1,NULL,NULL,99999,1),(239,'zato.email.smtp.get-list',1,'zato.server.service.internal.email.smtp.GetList',1,NULL,NULL,99999,1),(240,'zato.service.get-request-response',1,'zato.server.service.internal.service.GetRequestResponse',1,NULL,NULL,99999,1),(241,'zato.pubsub.topics.delete',1,'zato.server.service.internal.pubsub.topics.Delete',1,NULL,NULL,99999,1),(242,'zato.kvdb.data-dict.translation.translate',1,'zato.server.service.internal.kvdb.data_dict.translation.Translate',1,NULL,NULL,99999,1),(243,'zato.security.openstack.change-password',1,'zato.server.service.internal.security.openstack.ChangePassword',1,NULL,NULL,99999,1),(244,'zato.notif.cloud.openstack.swift.delete',1,'zato.server.service.internal.notif.cloud.openstack.swift.Delete',1,NULL,NULL,99999,1),(245,'zato.outgoing.odoo.delete',1,'zato.server.service.internal.outgoing.odoo.Delete',1,NULL,NULL,99999,1),(246,'zato.server.message.xpath.get-list',1,'zato.server.service.internal.message.xpath.GetList',1,NULL,NULL,99999,1),(247,'zato.security.oauth.create',1,'zato.server.service.internal.security.oauth.Create',1,NULL,NULL,99999,1),(248,'zato.notif.cloud.openstack.swift.get-list',1,'zato.server.service.internal.notif.cloud.openstack.swift.GetList',1,NULL,NULL,99999,1),(249,'zato.search.es.edit',1,'zato.server.service.internal.search.es.Edit',1,NULL,NULL,99999,1),(250,'zato.security.rbac.role.edit',1,'zato.server.service.internal.security.rbac.role.Edit',1,NULL,NULL,99999,1),(251,'zato.service.slow-response.get-list',1,'zato.server.service.internal.service.GetSlowResponseList',1,NULL,NULL,99999,1),(252,'zato.email.smtp.ping',1,'zato.server.service.internal.email.smtp.Ping',1,NULL,NULL,99999,1),(253,'zato.service.invoke',1,'zato.server.service.internal.service.Invoke',1,NULL,NULL,99999,1),(254,'zato.kvdb.data-dict.dictionary.get-last-id',1,'zato.server.service.internal.kvdb.data_dict.dictionary.GetLastID',1,NULL,NULL,99999,1),(255,'zato.outgoing.odoo.ping',1,'zato.server.service.internal.outgoing.odoo.Ping',1,NULL,NULL,99999,1),(256,'zato.channel.amqp.edit',1,'zato.server.service.internal.channel.amqp.Edit',1,NULL,NULL,99999,1),(257,'zato.query.cassandra.create',1,'zato.server.service.internal.query.cassandra.Create',1,NULL,NULL,99999,1),(258,'zato.ping',1,'zato.server.service.internal.Ping',1,NULL,NULL,99999,1);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sql_pool`
--

DROP TABLE IF EXISTS `sql_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sql_pool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `username` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `db_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `engine` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `extra` blob,
  `host` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `pool_size` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cluster_id` (`cluster_id`,`name`),
  CONSTRAINT `sql_pool_ibfk_1` FOREIGN KEY (`cluster_id`) REFERENCES `cluster` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sql_pool`
--

LOCK TABLES `sql_pool` WRITE;
/*!40000 ALTER TABLE `sql_pool` DISABLE KEYS */;
/*!40000 ALTER TABLE `sql_pool` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-25  3:00:03
